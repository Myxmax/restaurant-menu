export type UserRole = 'super_admin' | 'restaurant_admin' | 'kitchen_staff' | 'customer';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  restaurantId?: string; // If admin or kitchen staff
  name: string;
  createdAt: string;
}

export interface LoyaltyConfig {
  pointsPerDollar: number;
  pointsThresholdForDiscount: number;
  discountValue: number; // e.g., $5 off or percentage
}

export interface Restaurant {
  id: string;
  name: string;
  nameFa: string;
  slug: string; // url-friendly name
  description: string;
  descriptionFa: string;
  logo: string;
  banner: string;
  primaryColor: string; // Tailwind color class or hex
  accentColor: string;
  address: string;
  addressFa: string;
  phone: string;
  workingHours: string;
  workingHoursFa: string;
  subscriptionStatus: 'active' | 'expired' | 'trial';
  subscriptionExpiry: string;
  loyaltyConfig: LoyaltyConfig;
  qrScansCount: number;
}

export interface Category {
  id: string;
  restaurantId: string;
  name: string;
  nameFa: string;
  icon: string; // Lucide icon name
  sortOrder: number;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  categoryId: string;
  name: string;
  nameFa: string;
  description: string;
  descriptionFa: string;
  price: number;
  discountPrice?: number;
  image: string;
  isAvailable: boolean;
  prepTimeMinutes: number;
  calories?: number;
  isVegetarian?: boolean;
  isSpicy?: boolean;
  ratingsCount: number;
  averageRating: number;
}

export interface Table {
  id: string;
  restaurantId: string;
  tableNumber: string;
  status: 'empty' | 'occupied' | 'needs_cleaning';
  qrUrl: string;
}

export interface OrderItem {
  menuItemId: string;
  name: string;
  nameFa: string;
  price: number;
  quantity: number;
  notes?: string;
}

export type OrderType = 'dine_in' | 'delivery' | 'pickup';
export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'completed' | 'cancelled';

export interface Order {
  id: string;
  restaurantId: string;
  tableId?: string; // Optional if delivery or pickup
  tableNumber?: string;
  customerName: string;
  customerPhone?: string;
  deliveryAddress?: string;
  items: OrderItem[];
  type: OrderType;
  status: OrderStatus;
  orderNotes?: string;
  subtotal: number;
  discount: number;
  total: number;
  pointsEarned: number;
  pointsUsed?: number;
  couponApplied?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  restaurantId: string;
  menuItemId?: string; // General if not provided
  customerName: string;
  rating: number; // 1-5
  comment: string;
  createdAt: string;
}

export interface Coupon {
  id: string;
  restaurantId: string;
  code: string;
  discountPercent: number;
  minOrderValue: number;
  expiresAt: string;
  isActive: boolean;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  nameFa: string;
  priceMonthly: number;
  features: string[];
  featuresFa: string[];
}
