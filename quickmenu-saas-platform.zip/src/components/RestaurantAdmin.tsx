import React, { useState, useEffect } from 'react';
import { Restaurant, Category, MenuItem, Table, Order, Coupon, Review } from '../types';
import { Language, translations } from '../locale';
import {
  TrendingUp,
  QrCode,
  Layers,
  ShoppingBag,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  FileText,
  Clock,
  Sparkles,
  Flame,
  Ticket,
  ChevronRight,
  Eye,
  Settings,
  Star,
  Users
} from 'lucide-react';

interface RestaurantAdminProps {
  restaurant: Restaurant;
  lang: Language;
}

export const RestaurantAdmin: React.FC<RestaurantAdminProps> = ({ restaurant, lang }) => {
  const t = translations[lang];

  // Active Tab state: 'stats' | 'menu' | 'tables' | 'orders' | 'coupons' | 'settings'
  const [activeTab, setActiveTab] = useState<'stats' | 'menu' | 'tables' | 'orders' | 'coupons' | 'settings'>('stats');

  // Database States
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [tables, setTables] = useState<Table[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);

  // Category Forms state
  const [isCatFormOpen, setIsCatFormOpen] = useState<boolean>(false);
  const [catNameEn, setCatNameEn] = useState<string>('');
  const [catNameFa, setCatNameFa] = useState<string>('');
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  // Food Item Form state
  const [isItemFormOpen, setIsItemFormOpen] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [itemName, setItemName] = useState<string>('');
  const [itemNameFa, setItemNameFa] = useState<string>('');
  const [itemDesc, setItemDesc] = useState<string>('');
  const [itemDescFa, setItemDescFa] = useState<string>('');
  const [itemPrice, setItemPrice] = useState<string>('');
  const [itemDiscountPrice, setItemDiscountPrice] = useState<string>('');
  const [itemImage, setItemImage] = useState<string>('');
  const [itemPrepTime, setItemPrepTime] = useState<string>('15');
  const [itemCatId, setItemCatId] = useState<string>('');
  const [itemCalories, setItemCalories] = useState<string>('');
  const [itemIsVeg, setItemIsVeg] = useState<boolean>(false);
  const [itemIsSpicy, setItemIsSpicy] = useState<boolean>(false);

  // Table Form state
  const [tableNum, setTableNum] = useState<string>('');
  const [selectedQRTable, setSelectedQRTable] = useState<Table | null>(null);

  // Coupon Form state
  const [couponCode, setCouponCode] = useState<string>('');
  const [couponPercent, setCouponPercent] = useState<string>('10');
  const [couponMinOrder, setCouponMinOrder] = useState<string>('15');
  const [couponExpiry, setCouponExpiry] = useState<string>('2026-12-31');

  // Restaurant Config Settings
  const [restName, setRestName] = useState<string>(restaurant.name);
  const [restNameFa, setRestNameFa] = useState<string>(restaurant.nameFa);
  const [restDesc, setRestDesc] = useState<string>(restaurant.description);
  const [restDescFa, setRestDescFa] = useState<string>(restaurant.descriptionFa);
  const [restPhone, setRestPhone] = useState<string>(restaurant.phone);
  const [restHours, setRestHours] = useState<string>(restaurant.workingHours);
  const [restHoursFa, setRestHoursFa] = useState<string>(restaurant.workingHoursFa);
  const [restPrimaryColor, setRestPrimaryColor] = useState<string>(restaurant.primaryColor);
  const [isSettingsSaved, setIsSettingsSaved] = useState<boolean>(false);

  // Load Admin Data
  const loadAllData = () => {
    fetch(`/api/restaurants/${restaurant.id}/categories`)
      .then(res => res.json())
      .then(data => {
        setCategories(data);
        if (data.length > 0) setItemCatId(data[0].id);
      })
      .catch(err => console.error(err));

    fetch(`/api/restaurants/${restaurant.id}/items`)
      .then(res => res.json())
      .then(data => setItems(data))
      .catch(err => console.error(err));

    fetch(`/api/restaurants/${restaurant.id}/tables`)
      .then(res => res.json())
      .then(data => setTables(data))
      .catch(err => console.error(err));

    fetch(`/api/restaurants/${restaurant.id}/orders`)
      .then(res => res.json())
      .then(data => setOrders(data))
      .catch(err => console.error(err));

    fetch(`/api/restaurants/${restaurant.id}/coupons`)
      .then(res => res.json())
      .then(data => setCoupons(data))
      .catch(err => console.error(err));

    fetch(`/api/restaurants/${restaurant.id}/reviews`)
      .then(res => res.json())
      .then(data => setReviews(data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    loadAllData();
  }, [restaurant.id]);

  // Handle Order Status Change
  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        // Reload order list
        loadAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Create or Update Category
  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catNameEn.trim()) return;

    try {
      const method = editingCategory ? 'PUT' : 'POST';
      const url = editingCategory ? `/api/categories/${editingCategory.id}` : '/api/categories';
      const body = {
        restaurantId: restaurant.id,
        name: catNameEn,
        nameFa: catNameFa || catNameEn,
        icon: 'Flame'
      };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (res.ok) {
        setIsCatFormOpen(false);
        setEditingCategory(null);
        setCatNameEn('');
        setCatNameFa('');
        loadAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete Category
  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Are you sure you want to delete this category?')) return;
    try {
      const res = await fetch(`/api/categories/${id}`, { method: 'DELETE' });
      if (res.ok) loadAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Save / Update Menu Food Item
  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim() || !itemPrice) return;

    try {
      const method = editingItem ? 'PUT' : 'POST';
      const url = editingItem ? `/api/items/${editingItem.id}` : '/api/items';
      const body = {
        restaurantId: restaurant.id,
        categoryId: itemCatId,
        name: itemName,
        nameFa: itemNameFa || itemName,
        description: itemDesc,
        descriptionFa: itemDescFa || itemDesc,
        price: itemPrice,
        discountPrice: itemDiscountPrice || undefined,
        image: itemImage || undefined,
        prepTimeMinutes: itemPrepTime,
        calories: itemCalories || undefined,
        isVegetarian: itemIsVeg,
        isSpicy: itemIsSpicy
      };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (res.ok) {
        setIsItemFormOpen(false);
        setEditingItem(null);
        resetItemForm();
        loadAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const resetItemForm = () => {
    setItemName('');
    setItemNameFa('');
    setItemDesc('');
    setItemDescFa('');
    setItemPrice('');
    setItemDiscountPrice('');
    setItemImage('');
    setItemPrepTime('15');
    setItemCalories('');
    setItemIsVeg(false);
    setItemIsSpicy(false);
  };

  // Open Edit Item
  const openEditItem = (item: MenuItem) => {
    setEditingItem(item);
    setItemName(item.name);
    setItemNameFa(item.nameFa);
    setItemDesc(item.description);
    setItemDescFa(item.descriptionFa);
    setItemPrice(item.price.toString());
    setItemDiscountPrice(item.discountPrice?.toString() || '');
    setItemImage(item.image);
    setItemPrepTime(item.prepTimeMinutes.toString());
    setItemCatId(item.categoryId);
    setItemCalories(item.calories?.toString() || '');
    setItemIsVeg(!!item.isVegetarian);
    setItemIsSpicy(!!item.isSpicy);
    setIsItemFormOpen(true);
  };

  // Delete Item
  const handleDeleteItem = async (id: string) => {
    if (!confirm('Are you sure you want to delete this menu item?')) return;
    try {
      const res = await fetch(`/api/items/${id}`, { method: 'DELETE' });
      if (res.ok) loadAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Add Table
  const handleAddTable = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tableNum.trim()) return;

    try {
      const res = await fetch('/api/tables', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ restaurantId: restaurant.id, tableNumber: tableNum })
      });
      if (res.ok) {
        setTableNum('');
        loadAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete Table
  const handleDeleteTable = async (id: string) => {
    if (!confirm('Are you sure you want to delete this table?')) return;
    try {
      const res = await fetch(`/api/tables/${id}`, { method: 'DELETE' });
      if (res.ok) loadAllData();
    } catch (err) {
      console.error(err);
    }
  };

  // Add Coupon
  const handleAddCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;

    try {
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: restaurant.id,
          code: couponCode,
          discountPercent: couponPercent,
          minOrderValue: couponMinOrder,
          expiresAt: couponExpiry
        })
      });

      if (res.ok) {
        setCouponCode('');
        loadAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Save Restaurant Profile Config
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const res = await fetch(`/api/restaurants/${restaurant.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: restName,
          nameFa: restNameFa,
          description: restDesc,
          descriptionFa: restDescFa,
          phone: restPhone,
          workingHours: restHours,
          workingHoursFa: restHoursFa,
          primaryColor: restPrimaryColor
        })
      });

      if (res.ok) {
        setIsSettingsSaved(true);
        setTimeout(() => setIsSettingsSaved(false), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Dashboard Stats Calculations
  const grossSales = orders.filter(o => o.status === 'completed').reduce((sum, o) => sum + o.total, 0);
  const pendingOrdersCount = orders.filter(o => o.status === 'pending').length;
  const scansCount = restaurant.qrScansCount || 0;

  return (
    <div className="w-full min-h-screen bg-slate-50 flex flex-col md:flex-row" dir={lang === 'fa' ? 'rtl' : 'ltr'}>
      {/* Sidebar Navigation */}
      <div className={`w-full md:w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 ${lang === 'fa' ? 'border-l' : 'border-r'} border-slate-800`}>
        <div className="p-6 border-b border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-indigo-600/30">
            QM
          </div>
          <div>
            <h2 className="text-white font-bold leading-tight text-sm tracking-tight">{t.restaurantDashboard}</h2>
            <span className="text-[10px] text-slate-400 font-medium font-mono">#{restaurant.slug}</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 text-sm font-medium">
          <button
            onClick={() => setActiveTab('stats')}
            className={`w-full text-start py-2.5 px-4 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${activeTab === 'stats' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>{lang === 'fa' ? 'آمار و اطلاعات' : 'Dashboard Stats'}</span>
          </button>
          <button
            onClick={() => setActiveTab('menu')}
            className={`w-full text-start py-2.5 px-4 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${activeTab === 'menu' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <Layers className="w-4 h-4" />
            <span>{lang === 'fa' ? 'منو و دسته‌بندی‌ها' : 'Menu & Categories'}</span>
          </button>
          <button
            onClick={() => setActiveTab('tables')}
            className={`w-full text-start py-2.5 px-4 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${activeTab === 'tables' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <QrCode className="w-4 h-4" />
            <span>{lang === 'fa' ? 'کدهای QR و میزها' : 'QR Codes & Tables'}</span>
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full text-start py-2.5 px-4 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${activeTab === 'orders' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="flex-1">{lang === 'fa' ? 'مدیریت سفارشات زنده' : 'Live Order Management'}</span>
            {pendingOrdersCount > 0 && (
              <span className="bg-rose-500 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold">
                {pendingOrdersCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('coupons')}
            className={`w-full text-start py-2.5 px-4 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${activeTab === 'coupons' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <Ticket className="w-4 h-4" />
            <span>{lang === 'fa' ? 'کدهای تخفیف و باشگاه' : 'Coupons & Loyalty'}</span>
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full text-start py-2.5 px-4 rounded-xl flex items-center gap-3 transition-all cursor-pointer ${activeTab === 'settings' ? 'bg-indigo-600 text-white shadow-md' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <Settings className="w-4 h-4" />
            <span>{lang === 'fa' ? 'مشخصات و برندسازی' : 'Profile Branding'}</span>
          </button>
        </nav>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-6 md:p-8 overflow-y-auto h-screen pb-24 text-start">
        {/* TOP Bar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 pb-4 border-b border-slate-200/60">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight">
              {lang === 'fa' ? restaurant.nameFa : restaurant.name}
            </h1>
            <p className="text-sm text-slate-500 mt-1">{t.dashboardSubtitle}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs bg-emerald-50 text-emerald-700 font-semibold px-2.5 py-1.5 rounded-full border border-emerald-200/50">
              {lang === 'fa' ? 'وضعیت اشتراک: فعال' : 'Subscription Status: ACTIVE'}
            </span>
          </div>
        </div>

        {/* STATS VIEW */}
        {activeTab === 'stats' && (
          <div className="space-y-8 animate-fade-in">
            {/* Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">
                    {lang === 'fa' ? 'درآمد کل (دلار)' : 'Total Revenue'}
                  </span>
                  <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">${grossSales.toFixed(2)}</strong>
                </div>
                <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
                  <TrendingUp className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">
                    {lang === 'fa' ? 'اسکن بارکدهای QR' : 'Digital QR Scans'}
                  </span>
                  <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">{scansCount}</strong>
                </div>
                <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
                  <QrCode className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">
                    {lang === 'fa' ? 'میزهای فعال' : 'Active Tables'}
                  </span>
                  <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">
                    {tables.filter(t => t.status === 'occupied').length} / {tables.length}
                  </strong>
                </div>
                <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
                  <Layers className="w-6 h-6" />
                </div>
              </div>

              <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">
                    {lang === 'fa' ? 'نظرات ثبت شده' : 'Customer Reviews'}
                  </span>
                  <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">
                    {reviews.length} {t.reviewsCount}
                  </strong>
                </div>
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                  <Star className="w-6 h-6 fill-emerald-500 text-emerald-500" />
                </div>
              </div>
            </div>

            {/* Recent Orders Queue */}
            <div className="bg-white border border-slate-100 rounded-2xl shadow-xs overflow-hidden text-start">
              <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 className="font-bold text-slate-900">{t.orderHistory}</h3>
                <span className="text-xs text-slate-500">
                  {lang === 'fa' ? 'همگام‌سازی خودکار و لحظه‌ای آشپزخانه' : 'Live automatic kitchen feeds'}
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-start text-xs text-slate-600">
                  <thead className="bg-slate-50 text-[10px] uppercase text-slate-400 font-semibold tracking-wider">
                    <tr>
                      <th className="px-6 py-3 text-start">{lang === 'fa' ? 'شناسه سفارش' : 'Order ID'}</th>
                      <th className="px-6 py-3 text-start">{lang === 'fa' ? 'مشتری' : 'Customer'}</th>
                      <th className="px-6 py-3 text-start">{lang === 'fa' ? 'نوع' : 'Type'}</th>
                      <th className="px-6 py-3 text-start">{lang === 'fa' ? 'مبلغ' : 'Price'}</th>
                      <th className="px-6 py-3 text-start">{lang === 'fa' ? 'وضعیت' : 'Status'}</th>
                      <th className="px-6 py-3 text-start">{lang === 'fa' ? 'عملیات' : 'Actions'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {orders.slice(-5).reverse().map(order => (
                      <tr key={order.id} className="hover:bg-slate-50/40">
                        <td className="px-6 py-4 font-mono font-bold text-slate-900">#{order.id.toUpperCase()}</td>
                        <td className="px-6 py-4 text-start">
                          <strong className="text-slate-800 block">{order.customerName}</strong>
                          {order.customerPhone && <span className="text-slate-400 text-[10px]">{order.customerPhone}</span>}
                        </td>
                        <td className="px-6 py-4 uppercase font-semibold text-[10px] text-start">
                          {order.type === 'dine_in' ? (lang === 'fa' ? `حضوری (میز ${order.tableNumber})` : `Dine-In (Table ${order.tableNumber})`) : (lang === 'fa' ? (order.type === 'delivery' ? 'پیک / دلیوری' : 'بیرون‌بر') : order.type)}
                        </td>
                        <td className="px-6 py-4 font-mono font-semibold text-indigo-600">${order.total.toFixed(2)}</td>
                        <td className="px-6 py-4 text-start">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                            order.status === 'pending' ? 'bg-amber-100 text-amber-800' :
                            order.status === 'preparing' ? 'bg-indigo-100 text-indigo-800' :
                            order.status === 'ready' ? 'bg-teal-100 text-teal-800' :
                            order.status === 'completed' ? 'bg-emerald-100 text-emerald-800' :
                            'bg-rose-100 text-rose-800'
                          }`}>
                            {t[order.status as keyof typeof t] || order.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 flex gap-1.5">
                          {order.status === 'pending' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(order.id, 'preparing')}
                              className="px-2.5 py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all font-semibold cursor-pointer text-[10px]"
                            >
                              {lang === 'fa' ? 'تایید' : 'Accept'}
                            </button>
                          )}
                          {order.status === 'preparing' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(order.id, 'ready')}
                              className="px-2.5 py-1 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-all font-semibold cursor-pointer text-[10px]"
                            >
                              {lang === 'fa' ? 'آماده تحویل' : 'Mark Ready'}
                            </button>
                          )}
                          {order.status !== 'completed' && order.status !== 'cancelled' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(order.id, 'cancelled')}
                              className="px-2.5 py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-500 rounded-lg transition-all font-semibold cursor-pointer text-[10px]"
                            >
                              {lang === 'fa' ? 'لغو' : 'Cancel'}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* MENU & CATEGORIES VIEW */}
        {activeTab === 'menu' && (
          <div className="space-y-8 animate-fade-in">
            {/* Category Control Panel */}
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Menu Categories</h3>
                  <p className="text-xs text-slate-500">Categories organize foods for customer scrolling</p>
                </div>
                <button
                  onClick={() => {
                    setEditingCategory(null);
                    setCatNameEn('');
                    setCatNameFa('');
                    setIsCatFormOpen(true);
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.addCategory}</span>
                </button>
              </div>

              {/* Category creation Form */}
              {isCatFormOpen && (
                <form onSubmit={handleSaveCategory} className="mb-6 bg-slate-50 border border-slate-100 rounded-2xl p-4 animate-fade-in">
                  <h4 className="text-xs font-bold text-slate-700 block mb-3">
                    {editingCategory ? 'Edit Category' : 'Create New Category'}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.categoryName}</label>
                      <input
                        type="text"
                        required
                        value={catNameEn}
                        onChange={e => setCatNameEn(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.categoryNameFa}</label>
                      <input
                        type="text"
                        required
                        value={catNameFa}
                        onChange={e => setCatNameFa(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 text-right"
                      />
                    </div>
                  </div>
                  <div className="mt-4 flex gap-2 justify-end">
                    <button
                      type="button"
                      onClick={() => setIsCatFormOpen(false)}
                      className="px-3.5 py-2 bg-slate-200 text-slate-600 rounded-xl text-xs font-medium cursor-pointer"
                    >
                      {t.cancel}
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold cursor-pointer hover:bg-indigo-700 transition-all"
                    >
                      {t.save}
                    </button>
                  </div>
                </form>
              )}

              {/* Categories list table */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {categories.map(cat => (
                  <div key={cat.id} className="border border-slate-100 rounded-xl p-3 flex items-center justify-between bg-slate-50/40">
                    <div>
                      <strong className="text-xs text-slate-800 block">{cat.name}</strong>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{cat.nameFa}</span>
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => {
                          setEditingCategory(cat);
                          setCatNameEn(cat.name);
                          setCatNameFa(cat.nameFa);
                          setIsCatFormOpen(true);
                        }}
                        className="p-1 bg-white border border-slate-200 text-slate-500 rounded hover:bg-slate-50 transition-all cursor-pointer"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(cat.id)}
                        className="p-1 bg-white border border-slate-200 text-rose-500 rounded hover:bg-rose-50 transition-all cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Food Items Control Panel */}
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Menu Food Items</h3>
                  <p className="text-xs text-slate-500">Configure prices, availability, discounts, and culinary details</p>
                </div>
                <button
                  onClick={() => {
                    setEditingItem(null);
                    resetItemForm();
                    setIsItemFormOpen(true);
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.addFood}</span>
                </button>
              </div>

              {/* Add / Edit Food form drawer */}
              {isItemFormOpen && (
                <form onSubmit={handleSaveItem} className="mb-8 border border-slate-200 rounded-2xl p-5 bg-slate-50/80 animate-fade-in space-y-4">
                  <h4 className="text-xs font-bold text-slate-800 block">
                    {editingItem ? 'Modify Food details' : 'Draft New Menu Item'}
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.foodName} *</label>
                      <input
                        type="text"
                        required
                        value={itemName}
                        onChange={e => setItemName(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.foodNameFa} *</label>
                      <input
                        type="text"
                        required
                        value={itemNameFa}
                        onChange={e => setItemNameFa(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 text-right"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.foodDescription}</label>
                      <textarea
                        rows={2}
                        value={itemDesc}
                        onChange={e => setItemDesc(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 resize-none"
                      ></textarea>
                    </div>
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.foodDescriptionFa}</label>
                      <textarea
                        rows={2}
                        value={itemDescFa}
                        onChange={e => setItemDescFa(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 text-right resize-none"
                      ></textarea>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">Select Category *</label>
                      <select
                        value={itemCatId}
                        onChange={e => setItemCatId(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500"
                      >
                        {categories.map(c => (
                          <option key={c.id} value={c.id}>{c.name} ({c.nameFa})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.price} *</label>
                      <input
                        type="number"
                        step="0.01"
                        required
                        value={itemPrice}
                        onChange={e => setItemPrice(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.discountPrice}</label>
                      <input
                        type="number"
                        step="0.01"
                        value={itemDiscountPrice}
                        onChange={e => setItemDiscountPrice(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-slate-500 block mb-1">{t.prepTime} *</label>
                      <input
                        type="number"
                        required
                        value={itemPrepTime}
                        onChange={e => setItemPrepTime(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-slate-500 block mb-1">Image URL</label>
                      <input
                        type="text"
                        placeholder="https://..."
                        value={itemImage}
                        onChange={e => setItemImage(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div>
                      <label className="text-xs text-slate-500 block mb-1">Calories count (Optional)</label>
                      <input
                        type="number"
                        value={itemCalories}
                        onChange={e => setItemCalories(e.target.value)}
                        className="w-full p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex gap-4 items-center pt-2 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700">
                      <input
                        type="checkbox"
                        checked={itemIsVeg}
                        onChange={e => setItemIsVeg(e.target.checked)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                      />
                      <span>Vegetarian suitable</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700">
                      <input
                        type="checkbox"
                        checked={itemIsSpicy}
                        onChange={e => setItemIsSpicy(e.target.checked)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                      />
                      <span>Spicy kick</span>
                    </label>
                  </div>

                  <div className="mt-6 flex gap-2 justify-end pt-4 border-t border-slate-200/50">
                    <button
                      type="button"
                      onClick={() => setIsItemFormOpen(false)}
                      className="px-4 py-2 bg-slate-200 text-slate-600 rounded-xl text-xs font-medium cursor-pointer"
                    >
                      {t.cancel}
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold cursor-pointer hover:bg-indigo-700 transition-all"
                    >
                      {t.save}
                    </button>
                  </div>
                </form>
              )}

              {/* Items listing card items */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {items.map(item => (
                  <div key={item.id} className="border border-slate-100 rounded-2xl p-3 flex gap-3 bg-slate-50/20 relative">
                    <img src={item.image} alt="" className="w-16 h-16 rounded-xl object-cover shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <strong className="text-sm text-slate-900 block truncate">{item.name}</strong>
                        <span className="text-xs font-mono font-bold text-indigo-600 shrink-0">${item.price.toFixed(2)}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block truncate mt-0.5">{item.nameFa}</span>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-1">{item.description}</p>

                      <div className="flex justify-between items-center mt-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.isAvailable ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'}`}>
                          {item.isAvailable ? 'Available' : 'Unavailable'}
                        </span>

                        <div className="flex gap-1">
                          <button
                            onClick={() => openEditItem(item)}
                            className="p-1 bg-white border border-slate-200 text-slate-500 rounded hover:bg-slate-50 transition-all cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteItem(item.id)}
                            className="p-1 bg-white border border-slate-200 text-rose-500 rounded hover:bg-rose-50 transition-all cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* QR CODES & TABLES VIEW */}
        {activeTab === 'tables' && (
          <div className="space-y-8 animate-fade-in">
            {/* Create Table Form */}
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs">
              <h3 className="font-bold text-slate-900 text-lg mb-2">Configure Restaurant Tables</h3>
              <p className="text-xs text-slate-500 mb-6">Create dining tables to instantly configure distinct high-quality QR Codes</p>

              <form onSubmit={handleAddTable} className="flex gap-3 max-w-sm mb-6">
                <input
                  type="text"
                  required
                  placeholder="e.g., Table 5, Table VIP"
                  value={tableNum}
                  onChange={e => setTableNum(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs border border-slate-200 bg-white rounded-xl outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold cursor-pointer transition-all"
                >
                  Create Table QR
                </button>
              </form>

              {/* Table items with QR graphics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {tables.map(table => {
                  const relativeUrl = table.qrUrl;
                  // Construct full dev service mockup URL
                  const mockupLink = `${window.location.origin}${relativeUrl}`;

                  return (
                    <div
                      key={table.id}
                      className="border border-slate-100 rounded-2xl p-4 bg-slate-50/30 flex flex-col items-center text-center justify-between"
                    >
                      <div className="w-full flex justify-between items-center mb-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                          table.status === 'occupied' ? 'bg-rose-100 text-rose-800' :
                          table.status === 'needs_cleaning' ? 'bg-amber-100 text-amber-800' :
                          'bg-emerald-100 text-emerald-800'
                        }`}>
                          {table.status}
                        </span>
                        <button
                          onClick={() => handleDeleteTable(table.id)}
                          className="text-slate-400 hover:text-rose-500 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Mock QR Representation Vector */}
                      <div className="bg-white p-3.5 border border-slate-100 rounded-xl shadow-xs flex items-center justify-center flex-col relative w-24 h-24 mb-4">
                        <QrCode className="w-16 h-16 text-slate-800" />
                        <span className="text-[8px] text-indigo-600 font-mono font-semibold block mt-1">SCAN ME</span>
                      </div>

                      <div className="w-full">
                        <h4 className="font-bold text-slate-900 text-sm">{t.tableNumber}: {table.tableNumber}</h4>
                        <span className="text-[10px] text-slate-400 block mt-0.5 font-mono truncate max-w-xs">{mockupLink}</span>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-100 w-full flex gap-2">
                        <button
                          onClick={() => setSelectedQRTable(table)}
                          className="flex-1 py-1.5 bg-indigo-50 border border-indigo-100 text-indigo-700 hover:bg-indigo-100 transition-all rounded-lg text-xs font-semibold cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View QR Layout</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Interactive PDF/Print QR modal card */}
            {selectedQRTable && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
                <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center border-4 border-double border-indigo-100 relative shadow-2xl">
                  <button
                    onClick={() => setSelectedQRTable(null)}
                    className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-all p-1.5 rounded-full bg-slate-100 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <span className="text-[10px] uppercase text-indigo-600 tracking-widest font-extrabold block mb-1">
                    {restaurant.name.toUpperCase()}
                  </span>
                  <h3 className="text-xl font-bold text-slate-950">{t.tableNumber} {selectedQRTable.tableNumber}</h3>

                  {/* QR Vector Illustration */}
                  <div className="my-6 bg-slate-50 border border-slate-100 p-6 rounded-2xl flex items-center justify-center flex-col max-w-[200px] mx-auto shadow-inner">
                    <div className="bg-white p-4 border-2 border-indigo-600 rounded-xl flex items-center justify-center relative shadow-md">
                      <QrCode className="w-32 h-32 text-indigo-950" />
                    </div>
                    <span className="text-[10px] text-slate-500 font-bold tracking-widest mt-2 block font-mono text-indigo-600">SCAN & ORDER</span>
                  </div>

                  <div className="space-y-3">
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      Scan the QR code with your mobile camera to instantly explore our menu and order directly!
                    </p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed font-sans mt-1 text-right border-t border-slate-100 pt-3" dir="rtl">
                      دوربین گوشی خود را روی کد اسکن کنید تا منوی دیجیتال {restaurant.nameFa} باز شود و سفارش خود را ثبت کنید.
                    </p>
                  </div>

                  <div className="mt-6 flex gap-2">
                    <button
                      onClick={() => window.print()}
                      className="flex-1 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold cursor-pointer transition-all"
                    >
                      Print Signage
                    </button>
                    <button
                      onClick={() => alert('Download simulated. Highly stylized QR code is ready for printer.')}
                      className="flex-1 py-2 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-xl text-xs font-semibold cursor-pointer transition-all hover:bg-indigo-100"
                    >
                      Download SVG
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* LIVE ORDER MANAGEMENT VIEW */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-white border border-slate-100 rounded-2xl shadow-xs overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 className="font-bold text-slate-900">Live Active Orders Queue</h3>
                <span className="text-xs text-indigo-600 font-medium animate-pulse">● Live polling enabled</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="bg-slate-50 text-[10px] uppercase text-slate-400 font-semibold tracking-wider">
                    <tr>
                      <th className="px-6 py-3">ID</th>
                      <th className="px-6 py-3">Customer Info</th>
                      <th className="px-6 py-3">Ordered Items</th>
                      <th className="px-6 py-3">Special Instructions</th>
                      <th className="px-6 py-3">Total Value</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {orders.slice().reverse().map(order => (
                      <tr key={order.id} className="hover:bg-slate-50/40">
                        <td className="px-6 py-4 font-mono font-bold text-slate-900">#{order.id.toUpperCase()}</td>
                        <td className="px-6 py-4">
                          <strong className="text-slate-800 block">{order.customerName}</strong>
                          {order.customerPhone && <span className="text-slate-400 text-[10px] font-mono block mt-0.5">{order.customerPhone}</span>}
                          {order.deliveryAddress && (
                            <span className="text-slate-500 text-[10px] block mt-1 leading-relaxed max-w-[150px] line-clamp-2">{order.deliveryAddress}</span>
                          )}
                          <span className="text-[10px] font-bold text-indigo-600 block mt-1 uppercase">
                            {order.type === 'dine_in' ? `Table ${order.tableNumber}` : order.type}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="space-y-1 max-w-[180px]">
                            {order.items.map((it, i) => (
                              <div key={i} className="flex justify-between items-start gap-2">
                                <span className="text-slate-700 font-medium text-[11px] line-clamp-1">
                                  {lang === 'fa' ? it.nameFa : it.name}
                                </span>
                                <span className="text-slate-400 font-mono text-[10px] shrink-0">x{it.quantity}</span>
                              </div>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-slate-500 italic max-w-[150px] truncate">
                          {order.orderNotes || '-'}
                        </td>
                        <td className="px-6 py-4 font-mono font-semibold text-indigo-600">${order.total.toFixed(2)}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                            order.status === 'pending' ? 'bg-amber-100 text-amber-800' :
                            order.status === 'preparing' ? 'bg-indigo-100 text-indigo-800' :
                            order.status === 'ready' ? 'bg-teal-100 text-teal-800' :
                            order.status === 'completed' ? 'bg-emerald-100 text-emerald-800' :
                            'bg-rose-100 text-rose-800'
                          }`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 flex flex-col gap-1.5">
                          {order.status === 'pending' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(order.id, 'preparing')}
                              className="w-full py-1 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-semibold cursor-pointer text-[10px]"
                            >
                              Accept & Prepare
                            </button>
                          )}
                          {order.status === 'preparing' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(order.id, 'ready')}
                              className="w-full py-1 bg-teal-600 text-white rounded-lg hover:bg-teal-700 font-semibold cursor-pointer text-[10px]"
                            >
                              Ready to Serve
                            </button>
                          )}
                          {order.status === 'ready' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(order.id, 'completed')}
                              className="w-full py-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 font-semibold cursor-pointer text-[10px]"
                            >
                              Complete
                            </button>
                          )}
                          {order.status !== 'completed' && order.status !== 'cancelled' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(order.id, 'cancelled')}
                              className="w-full py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-500 rounded-lg font-semibold cursor-pointer text-[10px]"
                            >
                              Cancel
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* COUPONS & LOYALTY VIEW */}
        {activeTab === 'coupons' && (
          <div className="space-y-8 animate-fade-in">
            {/* Loyalty Configuration Summary */}
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs">
              <h3 className="font-bold text-slate-900 text-lg mb-2">Customer Loyalty System</h3>
              <p className="text-xs text-slate-500 mb-6">Configure custom thresholds for automatic reward allocations</p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/40">
                  <span className="text-[10px] text-slate-400 font-bold block">Points per Dollar</span>
                  <strong className="text-lg text-slate-900 font-bold block mt-1">15 points</strong>
                </div>
                <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/40">
                  <span className="text-[10px] text-slate-400 font-bold block">Discount Threshold</span>
                  <strong className="text-lg text-slate-900 font-bold block mt-1">300 points</strong>
                </div>
                <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/40">
                  <span className="text-[10px] text-slate-400 font-bold block">Reward Value</span>
                  <strong className="text-lg text-slate-900 font-bold block mt-1">$5.00 off</strong>
                </div>
              </div>
            </div>

            {/* Coupons Management */}
            <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs">
              <h3 className="font-bold text-slate-900 text-lg mb-2">Manage Discount Coupons</h3>
              <p className="text-xs text-slate-500 mb-6">Create promotional discount codes for active customer checkouts</p>

              <form onSubmit={handleAddCoupon} className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 bg-slate-50 border border-slate-100 p-4 rounded-xl">
                <div>
                  <label className="text-[10px] text-slate-500 block mb-1">Coupon Code</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., BLACKFRIDAY"
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-none uppercase"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-1">Discount Percent (%)</label>
                  <input
                    type="number"
                    required
                    value={couponPercent}
                    onChange={e => setCouponPercent(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-1">Min Order Value ($)</label>
                  <input
                    type="number"
                    required
                    value={couponMinOrder}
                    onChange={e => setCouponMinOrder(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-none"
                  />
                </div>
                <div className="flex gap-2 items-end">
                  <button
                    type="submit"
                    className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all cursor-pointer"
                  >
                    Create Coupon
                  </button>
                </div>
              </form>

              {/* Coupons List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {coupons.map(cp => (
                  <div key={cp.id} className="border border-slate-100 rounded-xl p-3 flex justify-between items-center bg-slate-50/20">
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-sm text-slate-900">{cp.code}</strong>
                        <span className="bg-emerald-50 text-emerald-700 text-[10px] px-1.5 py-0.5 rounded font-bold">-{cp.discountPercent}%</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-1">Min Order Value: ${cp.minOrderValue.toFixed(2)}</span>
                    </div>
                    <span className="text-xs text-slate-400">Expires: {cp.expiresAt}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* PROFILE BRANDING VIEW */}
        {activeTab === 'settings' && (
          <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-xs max-w-2xl animate-fade-in">
            <h3 className="font-bold text-slate-900 text-lg mb-2">Restaurant Branding Configuration</h3>
            <p className="text-xs text-slate-500 mb-6">Customize display details, working hours, and branding colors</p>

            {isSettingsSaved && (
              <div className="mb-4 bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs p-3 rounded-xl flex items-center gap-2">
                <Check className="w-5 h-5 text-emerald-500" />
                <span>Branding configuration saved successfully!</span>
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Restaurant Name (English)</label>
                  <input
                    type="text"
                    required
                    value={restName}
                    onChange={e => setRestName(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Restaurant Name (Persian)</label>
                  <input
                    type="text"
                    required
                    value={restNameFa}
                    onChange={e => setRestNameFa(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none text-right"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Description (English)</label>
                  <textarea
                    rows={2}
                    value={restDesc}
                    onChange={e => setRestDesc(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none resize-none"
                  ></textarea>
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Description (Persian)</label>
                  <textarea
                    rows={2}
                    value={restDescFa}
                    onChange={e => setRestDescFa(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none text-right resize-none"
                  ></textarea>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Working Hours (English)</label>
                  <input
                    type="text"
                    value={restHours}
                    onChange={e => setRestHours(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Working Hours (Persian)</label>
                  <input
                    type="text"
                    value={restHoursFa}
                    onChange={e => setRestHoursFa(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none text-right"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={restPhone}
                    onChange={e => setRestPhone(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Primary Color (Hex)</label>
                  <input
                    type="text"
                    value={restPrimaryColor}
                    onChange={e => setRestPrimaryColor(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-all"
              >
                Save Branding
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
