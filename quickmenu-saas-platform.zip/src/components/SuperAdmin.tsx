import React, { useState, useEffect } from 'react';
import { Restaurant, SubscriptionPlan } from '../types';
import { Language, translations } from '../locale';
import {
  TrendingUp,
  Shield,
  Plus,
  Trash2,
  Check,
  X,
  PlusCircle,
  Clock,
  Settings,
  Store,
  DollarSign,
  Activity,
  User,
  ExternalLink
} from 'lucide-react';

interface SuperAdminProps {
  lang: Language;
}

export const SuperAdmin: React.FC<SuperAdminProps> = ({ lang }) => {
  const t = translations[lang];

  // Database stats
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [globalStats, setGlobalStats] = useState<any>({
    totalRestaurants: 0,
    activeSubs: 0,
    totalOrdersCount: 0,
    totalRevenue: 0,
    chartData: []
  });

  // New Restaurant Form State
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [newRestName, setNewRestName] = useState<string>('');
  const [newRestNameFa, setNewRestNameFa] = useState<string>('');
  const [newRestDesc, setNewRestDesc] = useState<string>('');
  const [newRestDescFa, setNewRestDescFa] = useState<string>('');
  const [newRestPhone, setNewRestPhone] = useState<string>('');
  const [newRestHours, setNewRestHours] = useState<string>('12:00 PM - 11:00 PM');
  const [newRestPrimaryColor, setNewRestPrimaryColor] = useState<string>('#3B82F6');
  const [formSuccess, setFormSuccess] = useState<boolean>(false);

  const fetchSaaSData = () => {
    fetch('/api/restaurants')
      .then(res => res.json())
      .then(data => setRestaurants(data))
      .catch(err => console.error(err));

    fetch('/api/superadmin/stats')
      .then(res => res.json())
      .then(data => setGlobalStats(data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchSaaSData();
  }, []);

  const handleRegisterRestaurant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRestName.trim()) return;

    try {
      const res = await fetch('/api/restaurants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newRestName,
          nameFa: newRestNameFa || newRestName,
          description: newRestDesc,
          descriptionFa: newRestDescFa || newRestDesc,
          phone: newRestPhone,
          workingHours: newRestHours,
          primaryColor: newRestPrimaryColor
        })
      });

      if (res.ok) {
        setFormSuccess(true);
        setNewRestName('');
        setNewRestNameFa('');
        setNewRestDesc('');
        setNewRestDescFa('');
        setNewRestPhone('');
        fetchSaaSData();
        setTimeout(() => {
          setFormSuccess(false);
          setIsFormOpen(false);
        }, 2000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Render elegant custom inline SVG chart
  const renderTrendsChart = () => {
    const data = globalStats.chartData || [];
    if (data.length === 0) return null;

    // Dimensions
    const width = 500;
    const height = 150;
    const padding = 20;

    const maxVal = Math.max(...data.map((d: any) => d.revenue || 10), 50);

    // Calculate coordinates
    const points = data.map((d: any, idx: number) => {
      const x = padding + (idx * (width - padding * 2)) / (data.length - 1);
      const y = height - padding - ((d.revenue || 0) * (height - padding * 2)) / maxVal;
      return `${x},${y}`;
    }).join(' ');

    return (
      <div className="w-full h-48 bg-white border border-slate-100 rounded-2xl p-4 shadow-xs mt-6 text-start">
        <h3 className="text-xs font-bold text-slate-800 mb-3 flex items-center gap-1.5 uppercase tracking-wide">
          <Activity className="w-4 h-4 text-indigo-500" />
          <span>{lang === 'fa' ? 'نمودار روند فروش پلتفرم در ۷ روز گذشته (دلار)' : '7-Day Platform Sales Trend'}</span>
        </h3>
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-32 overflow-visible">
          {/* Grids */}
          <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#f1f5f9" strokeWidth="2" />
          <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="#f8fafc" strokeWidth="1" strokeDasharray="3" />

          {/* Path line */}
          <polyline
            fill="none"
            stroke="#6366f1"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={points}
          />

          {/* Dots and Labels */}
          {data.map((d: any, idx: number) => {
            const x = padding + (idx * (width - padding * 2)) / (data.length - 1);
            const y = height - padding - ((d.revenue || 0) * (height - padding * 2)) / maxVal;

            return (
              <g key={idx}>
                <circle cx={x} cy={y} r="4" fill="#4f46e5" stroke="#ffffff" strokeWidth="2" />
                <text x={x} y={y - 8} fontSize="8" fontFamily="monospace" textAnchor="middle" fill="#64748b" fontWeight="bold">
                  ${d.revenue}
                </text>
                <text x={x} y={height - 4} fontSize="7" textAnchor="middle" fill="#94a3b8">
                  {d.date.substring(5)}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    );
  };

  return (
    <div className="w-full min-h-screen bg-slate-50 p-6 md:p-8 text-start font-sans" dir={lang === 'fa' ? 'rtl' : 'ltr'}>
      {/* SaaS Admin Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 pb-4 border-b border-slate-200/60">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-600 rounded-xl text-white shadow-lg shadow-indigo-600/30">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">
              {lang === 'fa' ? 'پنل مدیریت ارشد سیستم (SaaS)' : 'SaaS Platform Admin'}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              {lang === 'fa' ? 'مانیتورینگ تلمتری سیستم، تعریف فوری رستوران‌های جدید و اشتراک‌های پلتفرم' : 'Global system telemetry, restaurant provisioning and subscription lifecycles'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsFormOpen(true)}
          className="px-4.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{lang === 'fa' ? 'ثبت و تعریف رستوران جدید' : 'Provision New Client'}</span>
        </button>
      </div>

      {/* Overview Analytics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              {lang === 'fa' ? 'کل رستوران‌های تعریف شده' : 'Total Franchises'}
            </span>
            <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">{globalStats.totalRestaurants}</strong>
          </div>
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <Store className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              {lang === 'fa' ? 'اشتراک‌های فعال' : 'Subscribed Clients'}
            </span>
            <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">{globalStats.activeSubs}</strong>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <Check className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              {lang === 'fa' ? 'تعداد سفارشات کل پلتفرم' : 'Global Orders Volume'}
            </span>
            <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">{globalStats.totalOrdersCount}</strong>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <Activity className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              {lang === 'fa' ? 'مجموع درآمد کل سیستم' : 'Aggregated Revenue'}
            </span>
            <strong className="text-2xl font-bold text-slate-900 font-mono block mt-1">${globalStats.totalRevenue?.toFixed(2)}</strong>
          </div>
          <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Render Chart */}
      {renderTrendsChart()}

      {/* Restaurants Registry Table */}
      <div className="mt-8 bg-white border border-slate-100 rounded-2xl shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
          <h3 className="font-bold text-slate-900 text-sm">
            {lang === 'fa' ? 'لیست رستوران‌های ثبت شده در سامانه' : 'Tenant Restaurants Registry'}
          </h3>
          <span className="text-xs text-slate-500 font-medium font-mono">
            {lang === 'fa' ? `${restaurants.length} رستوران فعال` : `${restaurants.length} active slots occupied`}
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs text-slate-600">
            <thead className="bg-slate-50 text-[10px] uppercase text-slate-400 font-semibold tracking-wider">
              <tr>
                <th className="px-6 py-3 text-start">{lang === 'fa' ? 'رستوران' : 'Franchise'}</th>
                <th className="px-6 py-3 text-start">{lang === 'fa' ? 'آدرس اختصاصی (Slug)' : 'Slug (Subdomain URL)'}</th>
                <th className="px-6 py-3 text-start">{lang === 'fa' ? 'ساعت کاری' : 'Working Hours'}</th>
                <th className="px-6 py-3 text-start">{lang === 'fa' ? 'رنگ سازمانی' : 'Theme Color'}</th>
                <th className="px-6 py-3 text-start">{lang === 'fa' ? 'وضعیت اشتراک' : 'Subscription'}</th>
                <th className="px-6 py-3 text-start">{lang === 'fa' ? 'عملیات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {restaurants.map(rest => (
                <tr key={rest.id} className="hover:bg-slate-50/40">
                  <td className="px-6 py-4 flex items-center gap-3 text-start">
                    <img src={rest.logo} alt="" className="w-9 h-9 rounded-lg object-cover border border-slate-100" />
                    <div>
                      <strong className="text-slate-800 block text-xs">{lang === 'fa' ? rest.nameFa : rest.name}</strong>
                      <span className="text-slate-400 text-[10px] block mt-0.5">{rest.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-mono text-xs font-semibold text-slate-600 text-start">
                    /r/{rest.slug}
                  </td>
                  <td className="px-6 py-4 text-start">{rest.workingHours}</td>
                  <td className="px-6 py-4 flex items-center gap-2 text-start">
                    <span className="w-3.5 h-3.5 rounded-full block border border-slate-200" style={{ backgroundColor: rest.primaryColor }}></span>
                    <span className="font-mono text-[10px] text-slate-500">{rest.primaryColor}</span>
                  </td>
                  <td className="px-6 py-4 text-start">
                    <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100 text-[10px] font-bold uppercase">
                      {lang === 'fa' ? 'فعال' : rest.subscriptionStatus}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-start">
                    <a
                      href={`/r/${rest.slug}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1 hover:underline text-[11px]"
                    >
                      <span>{lang === 'fa' ? 'ورود به منو' : 'Launch Menu'}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Provisioning Modal Drawer */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl w-full max-w-lg p-6 relative shadow-2xl animate-fade-in text-start" dir={lang === 'fa' ? 'rtl' : 'ltr'}>
            <button
              onClick={() => setIsFormOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-full bg-slate-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-lg font-bold text-slate-900 mb-1">
              {lang === 'fa' ? 'راه‌اندازی و ثبت فوری رستوران جدید' : 'Provision New Restaurant Franchise'}
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              {lang === 'fa' ? 'افزودن اطلاعات به بانک اطلاعاتی پلتفرم و تولید آدرس اختصاصی به صورت آنی' : 'Fills database and generates unique slug sub-paths instantly'}
            </p>

            {formSuccess && (
              <div className="mb-4 bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs p-3 rounded-xl flex items-center gap-2">
                <Check className="w-5 h-5 text-emerald-500" />
                <span>
                  {lang === 'fa' ? 'رستوران جدید با موفقیت ثبت شد! در حال انتقال...' : 'Restaurant client provisioned successfully! Redirecting...'}
                </span>
              </div>
            )}

            <form onSubmit={handleRegisterRestaurant} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {lang === 'fa' ? 'نام به انگلیسی *' : 'Franchise Name (EN) *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Pizza Palace"
                    value={newRestName}
                    onChange={e => setNewRestName(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {lang === 'fa' ? 'نام به فارسی *' : 'Franchise Name (FA) *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثلا پیتزا پلاس"
                    value={newRestNameFa}
                    onChange={e => setNewRestNameFa(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {lang === 'fa' ? 'توضیحات کوتاه (EN)' : 'Description (EN)'}
                  </label>
                  <textarea
                    rows={2}
                    value={newRestDesc}
                    onChange={e => setNewRestDesc(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500 resize-none"
                  ></textarea>
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {lang === 'fa' ? 'توضیحات کوتاه (FA)' : 'Description (FA)'}
                  </label>
                  <textarea
                    rows={2}
                    value={newRestDescFa}
                    onChange={e => setNewRestDescFa(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500 resize-none"
                  ></textarea>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {lang === 'fa' ? 'ساعات کاری' : 'Working Hours'}
                  </label>
                  <input
                    type="text"
                    value={newRestHours}
                    onChange={e => setNewRestHours(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">
                    {lang === 'fa' ? 'تلفن تماس' : 'Contact Phone'}
                  </label>
                  <input
                    type="text"
                    placeholder="021-..."
                    value={newRestPhone}
                    onChange={e => setNewRestPhone(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-500 block mb-1">
                  {lang === 'fa' ? 'رنگ برند سازمانی (Hex)' : 'Primary Brand Color (Hex)'}
                </label>
                <input
                  type="text"
                  value={newRestPrimaryColor}
                  onChange={e => setNewRestPrimaryColor(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500 font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-sm transition-all shadow-lg shadow-indigo-100 cursor-pointer"
              >
                {lang === 'fa' ? 'ایجاد و فعال‌سازی سریع' : 'Provision Client'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
