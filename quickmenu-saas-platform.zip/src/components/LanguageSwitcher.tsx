import React from 'react';
import { Language } from '../locale';
import { Globe } from 'lucide-react';

interface LanguageSwitcherProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({ currentLang, onLanguageChange }) => {
  const toggleLanguage = () => {
    const nextLang = currentLang === 'en' ? 'fa' : 'en';
    onLanguageChange(nextLang);
    document.documentElement.dir = nextLang === 'fa' ? 'rtl' : 'ltr';
    document.documentElement.lang = nextLang;
  };

  return (
    <button
      id="lang-switcher-btn"
      onClick={toggleLanguage}
      className="flex items-center gap-2 px-3.5 py-2 text-sm font-medium bg-white border border-slate-200 hover:border-slate-300 rounded-full shadow-sm text-slate-700 transition-all cursor-pointer hover:bg-slate-50"
    >
      <Globe className="w-4 h-4 text-slate-500" />
      <span>{currentLang === 'en' ? 'فارسی (RTL)' : 'English (LTR)'}</span>
    </button>
  );
};
