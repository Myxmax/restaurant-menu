import React, { useState, useEffect } from 'react';
import { Order, OrderStatus } from '../types';
import { Language, translations } from '../locale';
import {
  Clock,
  Play,
  CheckCircle,
  XCircle,
  ChefHat,
  Utensils,
  ShoppingBag,
  MapPin,
  RefreshCw,
  Bell
} from 'lucide-react';

interface KitchenDashboardProps {
  restaurantId: string;
  lang: Language;
}

export const KitchenDashboard: React.FC<KitchenDashboardProps> = ({ restaurantId, lang }) => {
  const t = translations[lang];
  const [orders, setOrders] = useState<Order[]>([]);
  const [checkedItems, setCheckedItems] = useState<{ [key: string]: boolean }>({});
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const fetchActiveOrders = () => {
    setIsRefreshing(true);
    fetch(`/api/restaurants/${restaurantId}/orders`)
      .then(res => res.json())
      .then(data => {
        // Filter out completed and cancelled for KDS view
        const active = data.filter((o: Order) => o.status !== 'completed' && o.status !== 'cancelled');
        setOrders(active);
      })
      .catch(err => console.error(err))
      .finally(() => setIsRefreshing(false));
  };

  useEffect(() => {
    fetchActiveOrders();
    // Poll every 5 seconds for new orders
    const interval = setInterval(fetchActiveOrders, 5000);
    return () => clearInterval(interval);
  }, [restaurantId]);

  const handleUpdateStatus = async (orderId: string, status: OrderStatus) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchActiveOrders();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Toggle checklist for food plating
  const toggleItemCheck = (orderId: string, itemId: string, index: number) => {
    const key = `${orderId}-${itemId}-${index}`;
    setCheckedItems(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const calculateMinutesElapsed = (isoString: string) => {
    const elapsedMs = Date.now() - new Date(isoString).getTime();
    return Math.floor(elapsedMs / 1000 / 60);
  };

  // Categorize orders
  const pendingOrders = orders.filter(o => o.status === 'pending');
  const preparingOrders = orders.filter(o => o.status === 'preparing');
  const readyOrders = orders.filter(o => o.status === 'ready');

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 p-6 font-sans text-start" dir={lang === 'fa' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-slate-800 mb-8">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-rose-600 rounded-xl text-white shadow-lg shadow-rose-600/25">
            <ChefHat className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tight text-white">{t.kitchenView}</h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'fa' ? 'صفحه هوشمند نمایش سفارشات زنده برای پرسنل آشپزخانه و تحویل' : 'Real-time digital ticket feed for kitchen and expediting staff'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchActiveOrders}
            className="p-2 bg-slate-900 border border-slate-800 text-slate-400 hover:text-white rounded-lg cursor-pointer transition-all"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>
          <span className="text-xs font-semibold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3 py-1.5 rounded-full flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            {lang === 'fa' ? 'سیستم مانیتورینگ آنلاین است' : 'KDS Feed Online'}
          </span>
        </div>
      </div>

      {/* Grid columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* PENDING COLUMN */}
        <div className="bg-slate-900/60 border border-slate-900 rounded-2xl p-4 flex flex-col h-[75vh]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4 shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-amber-500 rounded-full"></span>
              <h3 className="font-bold text-sm tracking-tight uppercase text-slate-300">
                {lang === 'fa' ? 'سفارشات جدید ورودی' : 'Incoming Orders'}
              </h3>
            </div>
            <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] px-2 py-0.5 rounded-md font-bold">
              {pendingOrders.length}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-4 no-scrollbar">
            {pendingOrders.length === 0 ? (
              <div className="text-center py-12 text-slate-500 italic text-xs">
                {lang === 'fa' ? 'هیچ فیش سفارشی در صف انتظار نیست' : 'No pending tickets'}
              </div>
            ) : (
              pendingOrders.map(order => (
                <div key={order.id} className="bg-slate-900 border-l-4 border-amber-500 rounded-xl p-4 shadow-sm border border-slate-800">
                  <div className="flex justify-between items-start mb-2.5">
                    <div>
                      <span className="font-mono font-bold text-white text-sm">#{order.id.toUpperCase()}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {lang === 'fa' ? `مشتری: ${order.customerName}` : `By: ${order.customerName}`}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-amber-400 uppercase bg-amber-500/10 px-2 py-0.5 rounded">
                        {order.type === 'dine_in' ? (lang === 'fa' ? `میز ${order.tableNumber}` : `Table ${order.tableNumber}`) : (lang === 'fa' ? (order.type === 'delivery' ? 'پیک / دلیوری' : 'بیرون‌بر') : order.type)}
                      </span>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="space-y-2 py-2 border-y border-slate-800/80 my-3">
                    {order.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-xs font-semibold text-slate-300">
                        <span>{lang === 'fa' ? it.nameFa : it.name}</span>
                        <span className="font-mono text-slate-400">x{it.quantity}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between items-center mt-3 pt-1">
                    <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      {calculateMinutesElapsed(order.createdAt)} {lang === 'fa' ? 'دقیقه قبل' : 'mins ago'}
                    </span>

                    <button
                      onClick={() => handleUpdateStatus(order.id, 'preparing')}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>{lang === 'fa' ? 'شروع پخت' : 'Start Prep'}</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* PREPARING COLUMN */}
        <div className="bg-slate-900/60 border border-slate-900 rounded-2xl p-4 flex flex-col h-[75vh]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4 shrink-0">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
              </span>
              <h3 className="font-bold text-sm tracking-tight uppercase text-slate-300">
                {lang === 'fa' ? 'در حال آماده‌سازی و پخت' : 'Preparing / Plating'}
              </h3>
            </div>
            <span className="bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] px-2 py-0.5 rounded-md font-bold">
              {preparingOrders.length}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-4 no-scrollbar">
            {preparingOrders.length === 0 ? (
              <div className="text-center py-12 text-slate-500 italic text-xs">
                {lang === 'fa' ? 'هیچ فیش سفارشی در حال پخت نیست' : 'No active prep tickets'}
              </div>
            ) : (
              preparingOrders.map(order => (
                <div key={order.id} className="bg-slate-900 border-l-4 border-indigo-500 rounded-xl p-4 shadow-sm border border-slate-800">
                  <div className="flex justify-between items-start mb-2.5">
                    <div>
                      <span className="font-mono font-bold text-white text-sm">#{order.id.toUpperCase()}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {lang === 'fa' ? `مشتری: ${order.customerName}` : `By: ${order.customerName}`}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold text-indigo-400 uppercase bg-indigo-500/10 px-2 py-0.5 rounded">
                      {order.type === 'dine_in' ? (lang === 'fa' ? `میز ${order.tableNumber}` : `Table ${order.tableNumber}`) : (lang === 'fa' ? (order.type === 'delivery' ? 'پیک / دلیوری' : 'بیرون‌بر') : order.type)}
                    </span>
                  </div>

                  {/* Checklist Items for prep */}
                  <div className="space-y-2 py-2 border-y border-slate-800/80 my-3">
                    {order.items.map((it, idx) => {
                      const key = `${order.id}-${it.menuItemId}-${idx}`;
                      const isChecked = !!checkedItems[key];

                      return (
                        <div
                          key={idx}
                          onClick={() => toggleItemCheck(order.id, it.menuItemId, idx)}
                          className={`flex items-center justify-between text-xs font-semibold p-1 rounded hover:bg-slate-800/40 cursor-pointer transition-all ${isChecked ? 'text-slate-600 line-through' : 'text-slate-300'}`}
                        >
                          <span className="flex items-center gap-2">
                            <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center ${isChecked ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400' : 'border-slate-700'}`}>
                              {isChecked && <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>}
                            </span>
                            <span>{lang === 'fa' ? it.nameFa : it.name}</span>
                          </span>
                          <span className="font-mono">x{it.quantity}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Special notes */}
                  {order.orderNotes && (
                    <div className="text-[10px] bg-amber-500/5 border border-amber-500/10 p-2 rounded-lg text-amber-400 mb-3 italic">
                      {lang === 'fa' ? `توضیحات: ${order.orderNotes}` : `Note: ${order.orderNotes}`}
                    </div>
                  )}

                  <div className="flex justify-between items-center mt-3 pt-1">
                    <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      {calculateMinutesElapsed(order.createdAt)} {lang === 'fa' ? 'دقیقه گذشته' : 'mins elapsed'}
                    </span>

                    <button
                      onClick={() => handleUpdateStatus(order.id, 'ready')}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-emerald-950/40"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>{lang === 'fa' ? 'آماده شد' : 'Ready'}</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* READY / SERVICE COLUMN */}
        <div className="bg-slate-900/60 border border-slate-900 rounded-2xl p-4 flex flex-col h-[75vh]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4 shrink-0">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
              <h3 className="font-bold text-sm tracking-tight uppercase text-slate-300">
                {lang === 'fa' ? 'آماده سرویس و تحویل' : 'Ready for Service'}
              </h3>
            </div>
            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] px-2 py-0.5 rounded-md font-bold">
              {readyOrders.length}
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-4 no-scrollbar">
            {readyOrders.length === 0 ? (
              <div className="text-center py-12 text-slate-500 italic text-xs">
                {lang === 'fa' ? 'هیچ سفارشی آماده تحویل نیست' : 'No service-ready tickets'}
              </div>
            ) : (
              readyOrders.map(order => (
                <div key={order.id} className="bg-slate-900 border-l-4 border-emerald-500 rounded-xl p-4 shadow-sm border border-slate-800">
                  <div className="flex justify-between items-start mb-2.5">
                    <div>
                      <span className="font-mono font-bold text-white text-sm">#{order.id.toUpperCase()}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {lang === 'fa' ? `مشتری: ${order.customerName}` : `By: ${order.customerName}`}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-400 uppercase bg-emerald-500/10 px-2 py-0.5 rounded">
                      {order.type === 'dine_in' ? (lang === 'fa' ? `میز ${order.tableNumber}` : `Table ${order.tableNumber}`) : (lang === 'fa' ? (order.type === 'delivery' ? 'پیک / دلیوری' : 'بیرون‌بر') : order.type)}
                    </span>
                  </div>

                  <div className="space-y-1 py-1 text-xs text-slate-400">
                    {order.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between">
                        <span>{lang === 'fa' ? it.nameFa : it.name}</span>
                        <span className="font-mono">x{it.quantity}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex justify-between items-center">
                    <span className="text-[10px] text-slate-500 font-mono font-medium">{lang === 'fa' ? 'آماده تحویل' : 'Ready'}</span>
                    <button
                      onClick={() => handleUpdateStatus(order.id, 'completed')}
                      className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-white rounded-lg text-xs font-semibold cursor-pointer transition-all border border-slate-700"
                    >
                      {lang === 'fa' ? 'تحویل شد و خروج' : 'Complete & Clear'}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
