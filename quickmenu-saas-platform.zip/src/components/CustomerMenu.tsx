import React, { useState, useEffect } from 'react';
import { MenuItem, Category, Restaurant, Order, OrderType, OrderItem, Coupon, OrderStatus } from '../types';
import { Language, translations } from '../locale';
import {
  Search,
  ShoppingCart,
  Clock,
  Flame,
  Sparkles,
  Plus,
  Minus,
  Star,
  X,
  MapPin,
  User,
  Phone,
  Ticket,
  Check,
  AlertCircle,
  ChevronRight,
  ThumbsUp,
  Utensils
} from 'lucide-react';

interface CustomerMenuProps {
  restaurant: Restaurant;
  tableParam?: string; // e.g. "T2" from URL query
  lang: Language;
}

export const CustomerMenu: React.FC<CustomerMenuProps> = ({ restaurant, tableParam, lang }) => {
  const t = translations[lang];

  // Menu State
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterVeg, setFilterVeg] = useState<boolean>(false);
  const [filterSpicy, setFilterSpicy] = useState<boolean>(false);
  const [filterDiscount, setFilterDiscount] = useState<boolean>(false);

  // Selected Food Detail Modal
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [itemReviews, setItemReviews] = useState<any[]>([]);
  const [newReviewName, setNewReviewName] = useState<string>('');
  const [newReviewRating, setNewReviewRating] = useState<number>(5);
  const [newReviewComment, setNewReviewComment] = useState<string>('');
  const [reviewSuccess, setReviewSuccess] = useState<boolean>(false);

  // Cart State
  const [cart, setCart] = useState<{ item: MenuItem; quantity: number; notes: string }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [orderType, setOrderType] = useState<OrderType>(tableParam ? 'dine_in' : 'pickup');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [deliveryAddress, setDeliveryAddress] = useState<string>('');
  const [tableNumber, setTableNumber] = useState<string>(tableParam || '');
  const [specialInstructions, setSpecialInstructions] = useState<string>('');

  // Discount & Loyalty state
  const [couponCode, setCouponCode] = useState<string>('');
  const [couponApplied, setCouponApplied] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState<string>('');
  const [useLoyaltyPoints, setUseLoyaltyPoints] = useState<boolean>(false);
  const [customerPoints, setCustomerPoints] = useState<number>(120); // starting loyalty simulation

  // Order Submission State
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);
  const [trackingOrder, setTrackingOrder] = useState<Order | null>(null);
  const [isOrdering, setIsOrdering] = useState<boolean>(false);

  // Load Categories & Menu Items
  useEffect(() => {
    fetch(`/api/restaurants/${restaurant.id}/categories`)
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error(err));

    fetch(`/api/restaurants/${restaurant.id}/items`)
      .then(res => res.json())
      .then(data => setItems(data))
      .catch(err => console.error(err));

    // Increment scan count on mount if we have a table parameter
    if (tableParam) {
      fetch(`/api/restaurants/${restaurant.id}/scan`, { method: 'POST' }).catch(err => console.error(err));
    }
  }, [restaurant.id, tableParam]);

  // Handle active order status polling
  useEffect(() => {
    if (!placedOrder) return;

    const interval = setInterval(() => {
      fetch(`/api/orders/${placedOrder.id}`)
        .then(res => res.json())
        .then(data => {
          setTrackingOrder(data);
          if (data.status === 'completed' || data.status === 'cancelled') {
            clearInterval(interval);
          }
        })
        .catch(err => console.error(err));
    }, 5000); // Poll every 5 seconds

    return () => clearInterval(interval);
  }, [placedOrder]);

  // Fetch reviews for selected item
  useEffect(() => {
    if (!selectedItem) return;
    fetch(`/api/restaurants/${restaurant.id}/reviews`)
      .then(res => res.json())
      .then(data => {
        const filtered = data.filter((r: any) => r.menuItemId === selectedItem.id);
        setItemReviews(filtered);
      })
      .catch(err => console.error(err));
  }, [selectedItem, restaurant.id]);

  // Filtering Menu items
  const filteredItems = items.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.categoryId === selectedCategory;
    const nameStr = lang === 'fa' ? item.nameFa : item.name;
    const descStr = lang === 'fa' ? item.descriptionFa : item.description;
    const matchesSearch =
      nameStr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      descStr.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesVeg = !filterVeg || item.isVegetarian;
    const matchesSpicy = !filterSpicy || item.isSpicy;
    const matchesDiscount = !filterDiscount || !!item.discountPrice;

    return matchesCategory && matchesSearch && matchesVeg && matchesSpicy && matchesDiscount;
  });

  // Cart operations
  const addToCart = (item: MenuItem, notes: string = '') => {
    const existingIndex = cart.findIndex(c => c.item.id === item.id && c.notes === notes);
    if (existingIndex > -1) {
      const newCart = [...cart];
      newCart[existingIndex].quantity += 1;
      setCart(newCart);
    } else {
      setCart([...cart, { item, quantity: 1, notes }]);
    }
  };

  const updateQuantity = (index: number, delta: number) => {
    const newCart = [...cart];
    newCart[index].quantity += delta;
    if (newCart[index].quantity <= 0) {
      newCart.splice(index, 1);
    }
    setCart(newCart);
  };

  // Pricing calculations
  const subtotal = cart.reduce((sum, c) => {
    const price = c.item.discountPrice || c.item.price;
    return sum + price * c.quantity;
  }, 0);

  let discount = 0;
  if (couponApplied) {
    discount = (subtotal * couponApplied.discountPercent) / 100;
  }

  if (useLoyaltyPoints) {
    const pointsConfig = restaurant.loyaltyConfig;
    const setsOfPoints = Math.floor(customerPoints / pointsConfig.pointsThresholdForDiscount);
    discount += setsOfPoints * pointsConfig.discountValue;
  }

  const finalTotal = Math.max(0, subtotal - discount);

  // Apply Coupon Code
  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;

    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: restaurant.id,
          code: couponCode,
          subtotal
        })
      });
      const data = await res.json();
      if (data.valid) {
        setCouponApplied(data.coupon);
        setCouponError('');
      } else {
        setCouponError(data.message || t.invalidCoupon);
        setCouponApplied(null);
      }
    } catch (err) {
      setCouponError(t.invalidCoupon);
    }
  };

  // Submit Review
  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;

    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: restaurant.id,
          menuItemId: selectedItem.id,
          customerName: newReviewName,
          rating: newReviewRating,
          comment: newReviewComment
        })
      });
      if (res.ok) {
        const createdReview = await res.json();
        setItemReviews([createdReview, ...itemReviews]);
        setReviewSuccess(true);
        setNewReviewName('');
        setNewReviewComment('');
        // Update item average score locally
        const updatedItems = items.map(it => {
          if (it.id === selectedItem.id) {
            const count = it.ratingsCount + 1;
            const avg = (it.averageRating * it.ratingsCount + newReviewRating) / count;
            return { ...it, ratingsCount: count, averageRating: Math.round(avg * 10) / 10 };
          }
          return it;
        });
        setItems(updatedItems);
        setTimeout(() => setReviewSuccess(false), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Checkout submission
  const handlePlaceOrder = async () => {
    if (!customerName.trim()) return;
    if (orderType === 'dine_in' && !tableNumber) return;
    if (orderType === 'delivery' && !deliveryAddress.trim()) return;

    setIsOrdering(true);

    const orderItems: OrderItem[] = cart.map(c => ({
      menuItemId: c.item.id,
      name: c.item.name,
      nameFa: c.item.nameFa,
      price: c.item.discountPrice || c.item.price,
      quantity: c.quantity,
      notes: c.notes
    }));

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          restaurantId: restaurant.id,
          tableNumber: orderType === 'dine_in' ? tableNumber : undefined,
          customerName,
          customerPhone,
          deliveryAddress: orderType === 'delivery' ? deliveryAddress : undefined,
          items: orderItems,
          type: orderType,
          orderNotes: specialInstructions,
          couponCode: couponApplied?.code,
          pointsUsed: useLoyaltyPoints ? customerPoints : 0
        })
      });

      if (res.ok) {
        const orderData = await res.json();
        setPlacedOrder(orderData);
        setTrackingOrder(orderData);
        setCart([]);
        setIsCartOpen(false);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsOrdering(false);
    }
  };

  return (
    <div className="w-full min-h-screen pb-24 relative bg-slate-50 text-start" dir={lang === 'fa' ? 'rtl' : 'ltr'}>
      {/* Banner & Logo */}
      <div className="w-full h-48 md:h-64 overflow-hidden relative">
        <img
          src={restaurant.banner}
          alt={lang === 'fa' ? restaurant.nameFa : restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40 backdrop-blur-xs flex items-end">
          <div className="w-full max-w-4xl mx-auto px-4 pb-4 md:pb-6 flex items-center gap-4">
            <img
              src={restaurant.logo}
              alt="Logo"
              className="w-16 h-16 md:w-20 md:h-20 rounded-xl border-2 border-white object-cover bg-white shadow-md"
            />
            <div className="text-white text-start">
              <h1 className="text-xl md:text-3xl font-bold tracking-tight">
                {lang === 'fa' ? restaurant.nameFa : restaurant.name}
              </h1>
              <p className="text-xs md:text-sm text-slate-200 mt-1 max-w-md line-clamp-2">
                {lang === 'fa' ? restaurant.descriptionFa : restaurant.description}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Body */}
      <div className="max-w-4xl mx-auto px-4 mt-6">
        {/* Table Parameter Indicator */}
        {tableParam && (
          <div className="mb-4 bg-emerald-50 border border-emerald-100 rounded-xl p-3 flex items-center gap-3 text-emerald-800 text-start">
            <Utensils className="w-5 h-5 text-emerald-500 shrink-0" />
            <div className="text-sm">
              <span className="font-semibold">{t.tableNumber}: {tableParam}</span> - {lang === 'fa' ? 'سفارش شما مستقیماً به این میز ارسال می‌شود.' : 'Your orders will be delivered directly to this table.'}
            </div>
          </div>
        )}

        {/* Live Tracking Active Banner */}
        {trackingOrder && (
          <div className="mb-6 bg-white border border-slate-200 shadow-sm rounded-xl p-4 animate-fade-in text-start">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
                </span>
                <h3 className="font-semibold text-slate-900">{t.trackingTitle}</h3>
              </div>
              <span className="text-xs font-mono text-slate-500">#{trackingOrder.id.toUpperCase()}</span>
            </div>

            {/* Status Steps */}
            <div className="grid grid-cols-5 gap-1.5 text-center mt-2">
              {(['pending', 'preparing', 'ready', 'completed', 'cancelled'] as OrderStatus[]).map((st, i) => {
                const isActive = trackingOrder.status === st;
                const isPast =
                  ['pending', 'preparing', 'ready', 'completed'].indexOf(trackingOrder.status) >=
                  ['pending', 'preparing', 'ready', 'completed'].indexOf(st);
                const isCancelled = trackingOrder.status === 'cancelled';

                let stepColor = 'bg-slate-200 text-slate-400';
                if (isCancelled && st === 'cancelled') {
                  stepColor = 'bg-rose-500 text-white font-medium';
                } else if (isActive) {
                  stepColor = 'bg-indigo-600 text-white font-medium scale-105 shadow-sm';
                } else if (isPast && st !== 'cancelled') {
                  stepColor = 'bg-emerald-500 text-white';
                }

                return (
                  <div key={st} className="flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs ${stepColor} transition-all`}>
                      {isPast && st !== 'cancelled' && !isActive ? <Check className="w-4 h-4" /> : i + 1}
                    </div>
                    <span className={`text-[10px] mt-1.5 line-clamp-1 ${isActive ? 'text-indigo-600 font-bold' : 'text-slate-500'}`}>
                      {t[st]}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Search and Filters bar */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex flex-col gap-4 text-start">
          <div className="relative">
            <Search className={`absolute ${lang === 'fa' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400`} />
            <input
              id="menu-search-input"
              type="text"
              placeholder={t.searchPlaceholder}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full py-2.5 ${lang === 'fa' ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl text-sm outline-none transition-all`}
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <button
              onClick={() => setFilterVeg(!filterVeg)}
              className={`px-3 py-1.5 rounded-full border cursor-pointer transition-all flex items-center gap-1.5 ${filterVeg ? 'bg-emerald-50 border-emerald-300 text-emerald-700 font-medium' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`}
            >
              <Sparkles className="w-3 h-3 text-emerald-500" />
              {t.vegetarian}
            </button>
            <button
              onClick={() => setFilterSpicy(!filterSpicy)}
              className={`px-3 py-1.5 rounded-full border cursor-pointer transition-all flex items-center gap-1.5 ${filterSpicy ? 'bg-rose-50 border-rose-300 text-rose-700 font-medium' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`}
            >
              <Flame className="w-3 h-3 text-rose-500" />
              {t.spicy}
            </button>
            <button
              onClick={() => setFilterDiscount(!filterDiscount)}
              className={`px-3 py-1.5 rounded-full border cursor-pointer transition-all flex items-center gap-1.5 ${filterDiscount ? 'bg-amber-50 border-amber-300 text-amber-700 font-medium' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`}
            >
              <Ticket className="w-3 h-3 text-amber-500" />
              {lang === 'fa' ? 'تخفیف‌دار' : 'On Sale'}
            </button>
          </div>
        </div>

        {/* Categories Horizontal scroll */}
        <div className="mt-6 flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 text-sm font-medium rounded-xl whitespace-nowrap cursor-pointer transition-all ${selectedCategory === 'all' ? 'bg-slate-900 text-white shadow-sm' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}
          >
            {t.allCategories}
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 text-sm font-medium rounded-xl whitespace-nowrap cursor-pointer transition-all ${selectedCategory === cat.id ? 'bg-slate-900 text-white shadow-sm' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}
            >
              {lang === 'fa' ? cat.nameFa : cat.name}
            </button>
          ))}
        </div>

        {/* Food Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          {filteredItems.map(item => {
            const hasDiscount = !!item.discountPrice;
            const price = item.price;
            const finalPrice = item.discountPrice || item.price;

            return (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className="bg-white border border-slate-100 rounded-2xl p-3 shadow-xs hover:shadow-md transition-all flex gap-3 cursor-pointer relative"
              >
                <img
                  src={item.image}
                  alt={lang === 'fa' ? item.nameFa : item.name}
                  className="w-24 h-24 rounded-xl object-cover shrink-0"
                />

                <div className="flex flex-col justify-between flex-1">
                  <div>
                    <div className="flex items-start justify-between gap-1">
                      <h4 className="font-semibold text-slate-900 text-sm md:text-base line-clamp-1">
                        {lang === 'fa' ? item.nameFa : item.name}
                      </h4>
                      {item.ratingsCount > 0 && (
                        <div className="flex items-center gap-0.5 text-amber-500 shrink-0">
                          <Star className="w-3.5 h-3.5 fill-amber-500" />
                          <span className="text-xs font-bold font-mono">{item.averageRating}</span>
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      {lang === 'fa' ? item.descriptionFa : item.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-sm md:text-base font-bold font-mono text-slate-900">
                        ${finalPrice.toFixed(2)}
                      </span>
                      {hasDiscount && (
                        <span className="text-xs font-mono text-slate-400 line-through">
                          ${price.toFixed(2)}
                        </span>
                      )}
                    </div>

                    <button
                      id={`add-btn-${item.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        addToCart(item);
                      }}
                      className="p-1.5 bg-indigo-50 border border-indigo-100 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-all cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Tags overlay */}
                <div className="absolute top-2.5 left-2.5 flex flex-col gap-1">
                  {item.isVegetarian && (
                    <span className="bg-emerald-100 text-emerald-800 text-[9px] px-1.5 py-0.5 rounded-md font-medium">
                      {lang === 'fa' ? 'گیاهی' : 'VEG'}
                    </span>
                  )}
                  {item.isSpicy && (
                    <span className="bg-rose-100 text-rose-800 text-[9px] px-1.5 py-0.5 rounded-md font-medium">
                      {lang === 'fa' ? 'تند' : 'SPICY'}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Floating Cart Button */}
      {cart.length > 0 && (
        <button
          id="floating-cart-trigger"
          onClick={() => setIsCartOpen(true)}
          className="fixed bottom-6 right-6 left-6 md:left-auto md:w-80 bg-slate-900 hover:bg-slate-800 text-white p-4 rounded-xl shadow-xl flex items-center justify-between transition-all cursor-pointer z-40"
        >
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 text-white w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold">
              {cart.reduce((sum, c) => sum + c.quantity, 0)}
            </div>
            <span className="text-sm font-medium">{t.cart}</span>
          </div>
          <span className="font-bold font-mono text-base">${subtotal.toFixed(2)}</span>
        </button>
      )}

      {/* Item Detail & Reviews Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl w-full max-w-lg max-h-[85vh] overflow-y-auto shadow-2xl relative animate-fade-in">
            <button
              id="close-detail-modal"
              onClick={() => setSelectedItem(null)}
              className="absolute top-4 right-4 bg-slate-100 hover:bg-slate-200 text-slate-700 p-1.5 rounded-full z-10 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={selectedItem.image}
              alt={lang === 'fa' ? selectedItem.nameFa : selectedItem.name}
              className="w-full h-56 object-cover"
            />

            <div className="p-5 md:p-6">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-lg md:text-2xl font-bold text-slate-950">
                  {lang === 'fa' ? selectedItem.nameFa : selectedItem.name}
                </h3>
                <span className="text-lg font-bold font-mono text-indigo-600">
                  ${(selectedItem.discountPrice || selectedItem.price).toFixed(2)}
                </span>
              </div>

              {/* Badges row */}
              <div className="flex flex-wrap gap-2 items-center mt-3 text-xs text-slate-500">
                {selectedItem.prepTimeMinutes && (
                  <div className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-md">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{selectedItem.prepTimeMinutes} {t.mins}</span>
                  </div>
                )}
                {selectedItem.calories && (
                  <div className="bg-slate-100 px-2 py-1 rounded-md">
                    <span>{selectedItem.calories} {t.calories}</span>
                  </div>
                )}
                {selectedItem.isVegetarian && (
                  <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded-md font-medium border border-emerald-100">
                    {t.vegetarian}
                  </span>
                )}
                {selectedItem.isSpicy && (
                  <span className="bg-rose-50 text-rose-700 px-2 py-1 rounded-md font-medium border border-rose-100">
                    {t.spicy}
                  </span>
                )}
              </div>

              <p className="text-sm text-slate-600 mt-4 leading-relaxed">
                {lang === 'fa' ? selectedItem.descriptionFa : selectedItem.description}
              </p>

              {/* Add directly note & Cart inside details */}
              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-4">
                <span className="text-xs text-slate-400">
                  {t.loyaltyEarned}: <strong className="text-indigo-600">+{Math.floor((selectedItem.discountPrice || selectedItem.price) * (restaurant.loyaltyConfig.pointsPerDollar || 10))}</strong> {t.loyaltyPoints}
                </span>
                <button
                  id="add-detail-to-cart-btn"
                  onClick={() => {
                    addToCart(selectedItem);
                    setSelectedItem(null);
                  }}
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-md cursor-pointer transition-all"
                >
                  {t.addToCart}
                </button>
              </div>

              {/* Reviews Section */}
              <div className="mt-8 pt-6 border-t border-slate-100">
                <h4 className="font-bold text-slate-900 text-base mb-4 flex items-center justify-between">
                  <span>{t.reviews}</span>
                  {selectedItem.ratingsCount > 0 && (
                    <span className="text-xs text-slate-500 font-normal">
                      {selectedItem.averageRating} ★ ({selectedItem.ratingsCount} {t.reviewsCount})
                    </span>
                  )}
                </h4>

                {/* Submitting review */}
                <form onSubmit={handleSubmitReview} className="mb-6 bg-slate-50 border border-slate-100 p-4 rounded-2xl">
                  <span className="text-xs font-semibold text-slate-700 block mb-2">{t.leaveReview}</span>
                  {reviewSuccess && (
                    <div className="mb-3 bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs p-2.5 rounded-lg flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-500" />
                      <span>{lang === 'fa' ? 'امتیاز شما با موفقیت ثبت شد!' : 'Your review was submitted!'}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="text"
                      placeholder={t.customerName}
                      required
                      value={newReviewName}
                      onChange={e => setNewReviewName(e.target.value)}
                      className="p-2 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500"
                    />
                    <select
                      value={newReviewRating}
                      onChange={e => setNewReviewRating(parseInt(e.target.value))}
                      className="p-2 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500"
                    >
                      <option value="5">★★★★★ (5)</option>
                      <option value="4">★★★★☆ (4)</option>
                      <option value="3">★★★☆☆ (3)</option>
                      <option value="2">★★☆☆☆ (2)</option>
                      <option value="1">★☆☆☆☆ (1)</option>
                    </select>
                  </div>

                  <textarea
                    rows={2}
                    placeholder={t.commentPlaceholder}
                    required
                    value={newReviewComment}
                    onChange={e => setNewReviewComment(e.target.value)}
                    className="w-full mt-3 p-2.5 border border-slate-200 bg-white rounded-xl text-xs outline-none focus:border-indigo-500 resize-none"
                  ></textarea>

                  <button
                    type="submit"
                    className="w-full mt-2.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-medium transition-all cursor-pointer"
                  >
                    {t.submitReview}
                  </button>
                </form>

                {/* Review logs */}
                <div className="space-y-3 max-h-48 overflow-y-auto">
                  {itemReviews.length === 0 ? (
                    <p className="text-xs text-slate-400 italic text-center py-4">{t.noReviewsYet}</p>
                  ) : (
                    itemReviews.map((rev, idx) => (
                      <div key={idx} className="border-b border-slate-50 pb-2">
                        <div className="flex items-center justify-between text-xs">
                          <strong className="text-slate-800">{rev.customerName}</strong>
                          <div className="flex text-amber-500">
                            {Array.from({ length: rev.rating }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-amber-500" />
                            ))}
                          </div>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">{rev.comment}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cart Drawer / Overlay */}
      {isCartOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex justify-end z-50">
          <div className="bg-white w-full max-w-md h-full shadow-2xl p-6 flex flex-col justify-between overflow-y-auto relative animate-fade-in">
            {/* Header */}
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-lg font-bold text-slate-900">{t.cart}</h3>
                </div>
                <button
                  id="close-cart-drawer"
                  onClick={() => setIsCartOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-500 p-1.5 rounded-full cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items List */}
              <div className="space-y-4 py-4 max-h-[40vh] overflow-y-auto">
                {cart.length === 0 ? (
                  <p className="text-sm text-slate-400 italic text-center py-8">{t.emptyCart}</p>
                ) : (
                  cart.map((c, idx) => {
                    const price = c.item.discountPrice || c.item.price;
                    return (
                      <div key={idx} className="flex items-center justify-between gap-3 border-b border-slate-50 pb-3">
                        <div className="flex items-center gap-2.5">
                          <img src={c.item.image} alt="" className="w-12 h-12 rounded-lg object-cover" />
                          <div>
                            <h5 className="text-sm font-semibold text-slate-900">
                              {lang === 'fa' ? c.item.nameFa : c.item.name}
                            </h5>
                            <span className="text-xs text-indigo-600 font-mono font-medium">${price.toFixed(2)}</span>
                          </div>
                        </div>

                        {/* Adjust qty */}
                        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg p-1 text-xs">
                          <button
                            onClick={() => updateQuantity(idx, -1)}
                            className="p-1 hover:bg-white rounded text-slate-500 cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-bold w-4 text-center font-mono">{c.quantity}</span>
                          <button
                            onClick={() => updateQuantity(idx, 1)}
                            className="p-1 hover:bg-white rounded text-slate-500 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Order Options */}
              {cart.length > 0 && (
                <div className="pt-4 border-t border-slate-100">
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    {(['dine_in', 'delivery', 'pickup'] as OrderType[]).map(type => (
                      <button
                        key={type}
                        onClick={() => setOrderType(type)}
                        className={`py-2 px-1 text-center rounded-xl text-xs font-semibold cursor-pointer transition-all ${orderType === type ? 'bg-indigo-600 text-white shadow-sm' : 'bg-slate-50 border border-slate-100 text-slate-600 hover:bg-slate-100'}`}
                      >
                        {t[type]}
                      </button>
                    ))}
                  </div>

                  {/* Dynamic inputs based on type */}
                  <div className="space-y-3 text-start">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">{t.customerName} *</label>
                      <div className="relative">
                        <User className={`absolute ${lang === 'fa' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400`} />
                        <input
                          type="text"
                          required
                          placeholder={t.customerName}
                          value={customerName}
                          onChange={e => setCustomerName(e.target.value)}
                          className={`w-full ${lang === 'fa' ? 'pr-9 pl-3 text-right' : 'pl-9 pr-3 text-left'} py-2 text-xs bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl outline-none`}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">{t.customerPhone}</label>
                      <div className="relative">
                        <Phone className={`absolute ${lang === 'fa' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400`} />
                        <input
                          type="text"
                          placeholder={t.customerPhone}
                          value={customerPhone}
                          onChange={e => setCustomerPhone(e.target.value)}
                          className={`w-full ${lang === 'fa' ? 'pr-9 pl-3 text-right font-mono' : 'pl-9 pr-3 text-left font-mono'} py-2 text-xs bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl outline-none`}
                        />
                      </div>
                    </div>

                    {orderType === 'dine_in' && (
                      <div>
                        <label className="text-xs font-semibold text-slate-700 block mb-1">{t.tableNumber} *</label>
                        <input
                          type="text"
                          required
                          placeholder={t.tableNumber}
                          value={tableNumber}
                          onChange={e => setTableNumber(e.target.value)}
                          className={`w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl outline-none font-bold font-mono ${lang === 'fa' ? 'text-right' : 'text-left'}`}
                        />
                      </div>
                    )}

                    {orderType === 'delivery' && (
                      <div>
                        <label className="text-xs font-semibold text-slate-700 block mb-1">{t.deliveryAddress} *</label>
                        <div className="relative">
                          <MapPin className={`absolute ${lang === 'fa' ? 'right-3' : 'left-3'} top-2.5 w-4 h-4 text-slate-400`} />
                          <textarea
                            rows={2}
                            required
                            placeholder={t.deliveryAddress}
                            value={deliveryAddress}
                            onChange={e => setDeliveryAddress(e.target.value)}
                            className={`w-full ${lang === 'fa' ? 'pr-9 pl-3 text-right' : 'pl-9 pr-3 text-left'} py-2 text-xs bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl outline-none resize-none`}
                          ></textarea>
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">{t.specialInstructions}</label>
                      <textarea
                        rows={1}
                        placeholder={t.specialInstructions}
                        value={specialInstructions}
                        onChange={e => setSpecialInstructions(e.target.value)}
                        className={`w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-xl outline-none resize-none ${lang === 'fa' ? 'text-right' : 'text-left'}`}
                      ></textarea>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Price Calculations, Loyalty and Checkouts */}
            {cart.length > 0 && (
              <div className="border-t border-slate-100 pt-4 space-y-4 mt-6">
                {/* Coupon Code section */}
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t.couponPlaceholder}
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none uppercase"
                  />
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-medium hover:bg-slate-800 transition-all cursor-pointer"
                  >
                    {t.applyCoupon}
                  </button>
                </form>

                {couponApplied && (
                  <div className="bg-emerald-50 text-emerald-800 border border-emerald-100 text-xs p-2 rounded-lg flex items-center justify-between">
                    <span>{t.couponApplied} ({couponApplied.code})</span>
                    <strong>-{couponApplied.discountPercent}%</strong>
                  </div>
                )}
                {couponError && (
                  <div className="bg-rose-50 text-rose-800 border border-rose-100 text-[11px] p-2 rounded-lg flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                    <span>{couponError}</span>
                  </div>
                )}

                {/* Loyalty points discount simulation */}
                <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-3 flex items-center justify-between">
                  <div className="text-xs">
                    <span className="font-semibold text-indigo-950 block">{t.loyaltyPoints}</span>
                    <span className="text-[10px] text-indigo-700 block mt-0.5">
                      {lang === 'fa' ? `شما دارای ${customerPoints} امتیاز هستید.` : `You have ${customerPoints} points.`}
                    </span>
                  </div>
                  {customerPoints >= restaurant.loyaltyConfig.pointsThresholdForDiscount && (
                    <button
                      type="button"
                      onClick={() => setUseLoyaltyPoints(!useLoyaltyPoints)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${useLoyaltyPoints ? 'bg-indigo-600 text-white' : 'bg-white border border-indigo-200 text-indigo-700 hover:bg-indigo-50'}`}
                    >
                      {useLoyaltyPoints ? t.loyaltyUsed : t.usePointsButton}
                    </button>
                  )}
                </div>

                {/* Subtotal, Discount, Total lines */}
                <div className="space-y-1 text-xs text-start">
                  <div className="flex justify-between text-slate-500">
                    <span>{lang === 'fa' ? 'جمع کل اقلام' : 'Subtotal'}</span>
                    <span className="font-mono">${subtotal.toFixed(2)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-medium">
                      <span>{lang === 'fa' ? 'تخفیف اعمال شده' : 'Discount'}</span>
                      <span className="font-mono">-${discount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-900 font-bold text-sm pt-1.5 border-t border-slate-100">
                    <span>{t.totalPrice}</span>
                    <span className="font-mono text-indigo-600">${finalTotal.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  id="checkout-order-submit-btn"
                  onClick={handlePlaceOrder}
                  disabled={isOrdering || !customerName.trim() || (orderType === 'dine_in' && !tableNumber) || (orderType === 'delivery' && !deliveryAddress.trim())}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isOrdering ? '...' : t.placeOrder}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
