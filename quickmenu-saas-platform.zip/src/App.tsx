import React, { useState, useEffect } from 'react';
import { Restaurant, User } from './types';
import { Language, translations } from './locale';
import { LanguageSwitcher } from './components/LanguageSwitcher';
import { CustomerMenu } from './components/CustomerMenu';
import { RestaurantAdmin } from './components/RestaurantAdmin';
import { KitchenDashboard } from './components/KitchenDashboard';
import { SuperAdmin } from './components/SuperAdmin';
import {
  Utensils,
  QrCode,
  Shield,
  ChefHat,
  ShoppingBag,
  Ticket,
  ChevronRight,
  Sparkles,
  Info,
  Layers,
  Star,
  Globe,
  Settings,
  AppWindow
} from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('fa');
  const t = translations[lang];

  // Client-side Router State
  const [currentPath, setCurrentPath] = useState<string>(window.location.pathname);
  const [tableQuery, setTableQuery] = useState<string>('');
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Authentication Fallback
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('qm_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [authEmail, setAuthEmail] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  const [authLoading, setAuthLoading] = useState<boolean>(false);

  // Fetch all registered restaurants on mount
  useEffect(() => {
    // Set Persian RTL as the absolute default
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'fa';

    fetch('/api/restaurants')
      .then(res => res.json())
      .then(data => {
        setRestaurants(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading restaurants:', err);
        setLoading(false);
      });

    // Parse table query parameter
    const params = new URLSearchParams(window.location.search);
    const table = params.get('table');
    if (table) {
      setTableQuery(table);
    }
  }, []);

  // Update path on history navigation
  useEffect(() => {
    const handleLocationChange = () => {
      setCurrentPath(window.location.pathname);
      const params = new URLSearchParams(window.location.search);
      const table = params.get('table');
      if (table) {
        setTableQuery(table);
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  const navigateTo = (path: string, search: string = '') => {
    window.history.pushState({}, '', `${path}${search}`);
    setCurrentPath(path);
    if (search) {
      const params = new URLSearchParams(search);
      const table = params.get('table');
      if (table) setTableQuery(table);
    } else {
      setTableQuery('');
    }

    // Keep Persian RTL by default for a completely Persian experience
    setLang('fa');
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'fa';
  };

  // Mock Handle Portal Login
  const handlePortalLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail.trim()) return;

    setAuthLoading(true);
    setAuthError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: authEmail })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentUser(data.user);
        localStorage.setItem('qm_user', JSON.stringify(data.user));

        // Route accordingly
        if (data.user.role === 'super_admin') {
          navigateTo('/superadmin');
        } else if (data.user.role === 'restaurant_admin') {
          navigateTo('/admin');
        } else if (data.user.role === 'kitchen_staff') {
          navigateTo('/kitchen');
        } else {
          navigateTo('/');
        }
      } else {
        setAuthError('Authentication failed');
      }
    } catch (err) {
      setAuthError('Server communication error');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('qm_user');
    navigateTo('/');
  };

  // PWA Mock install
  const triggerPWAInstall = () => {
    alert(
      lang === 'fa'
        ? 'پیش‌نمایش نصب وب‌اپلیکیشن (PWA) با موفقیت فعال شد! به صفحه اصلی خود اضافه کنید.'
        : 'PWA installation triggered! Click Add to Home Screen in your browser shares sheet.'
    );
  };

  // ----------------------------------------------------
  // ROUTING RENDERER
  // ----------------------------------------------------

  // Customer Menu View Router
  if (currentPath.startsWith('/r/')) {
    const slug = currentPath.substring(3);
    const matchedRestaurant = restaurants.find(r => r.slug.toLowerCase() === slug.toLowerCase());

    if (loading) {
      return (
        <div className="w-full h-screen flex items-center justify-center bg-slate-50">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      );
    }

    if (!matchedRestaurant) {
      return (
        <div className="w-full h-screen flex flex-col items-center justify-center bg-slate-50 p-4">
          <Info className="w-12 h-12 text-slate-400 mb-3" />
          <h2 className="text-xl font-bold text-slate-900">
            {lang === 'fa' ? 'رستوران یافت نشد' : 'Restaurant Not Found'}
          </h2>
          <button
            onClick={() => navigateTo('/')}
            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold"
          >
            {lang === 'fa' ? 'بازگشت به خانه' : 'Go Back Home'}
          </button>
        </div>
      );
    }

    return (
      <div className="relative">
        <div className="absolute top-4 right-4 z-50 flex gap-2">
          <LanguageSwitcher currentLang={lang} onLanguageChange={setLang} />
          <button
            onClick={() => navigateTo('/')}
            className="px-3.5 py-2 text-sm font-medium bg-white/95 backdrop-blur-xs border border-slate-200/50 hover:border-slate-300 rounded-full shadow-sm text-slate-700 transition-all cursor-pointer hover:bg-slate-50"
          >
            {lang === 'fa' ? 'بازگشت به پورتال' : '← Portal'}
          </button>
        </div>
        <CustomerMenu restaurant={matchedRestaurant} tableParam={tableQuery} lang={lang} />
      </div>
    );
  }

  // Kitchen Dashboard View Router
  if (currentPath === '/kitchen') {
    const defaultId = currentUser?.restaurantId || restaurants[1]?.id || 'rest_burger';
    return (
      <div className="relative">
        <button
          onClick={() => navigateTo('/')}
          className="absolute top-4 right-4 z-50 px-3.5 py-1.5 text-xs font-semibold bg-slate-900 text-slate-400 hover:text-white border border-slate-800 rounded-lg cursor-pointer transition-all"
        >
          {lang === 'fa' ? '← بازگشت به پورتال' : '← Portal Home'}
        </button>
        <KitchenDashboard restaurantId={defaultId} lang={lang} />
      </div>
    );
  }

  // Restaurant Admin View Router
  if (currentPath === '/admin') {
    if (!currentUser || currentUser.role !== 'restaurant_admin') {
      return (
        <div className="w-full min-h-screen bg-slate-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 md:p-8 w-full max-w-sm shadow-xl text-center">
            <Settings className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-950 mb-1">
              {lang === 'fa' ? 'مدیریت پنل رستوران' : 'Restaurant Management'}
            </h2>
            <p className="text-xs text-slate-500 mb-6">
              {lang === 'fa' ? 'ایمیل ثبت شده ادمین رستوران را برای ورود به پنل مدیریت وارد کنید' : 'Enter registered administrator email to access dashboards'}
            </p>

            {authError && (
              <div className="mb-4 text-xs bg-rose-50 border border-rose-100 text-rose-800 p-2.5 rounded-xl">
                {authError === 'Authentication failed' && lang === 'fa' ? 'اطلاعات ورود نادرست است' : authError}
              </div>
            )}

            <form onSubmit={handlePortalLogin} className="space-y-4">
              <input
                type="email"
                required
                placeholder={lang === 'fa' ? 'مثلا: shandiz@quickmenu.com' : 'shandiz@quickmenu.com or burger@quickmenu.com'}
                value={authEmail}
                onChange={e => setAuthEmail(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl outline-none text-xs text-center"
              />
              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer hover:bg-indigo-700 transition-all"
              >
                {authLoading ? '...' : (lang === 'fa' ? 'ورود به پنل کاربری' : 'Access Console')}
              </button>
            </form>

            <button
              onClick={() => navigateTo('/')}
              className="mt-4 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              {lang === 'fa' ? '← بازگشت به پورتال اصلی' : '← Back to Sandbox'}
            </button>
          </div>
        </div>
      );
    }

    const adminRest = restaurants.find(r => r.id === currentUser.restaurantId) || restaurants[1];
    return (
      <div className="relative">
        <button
          onClick={handleLogout}
          className="absolute top-6 right-8 z-50 px-3.5 py-1.5 text-xs font-semibold bg-slate-100 border border-slate-200 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer transition-all"
        >
          {lang === 'fa' ? 'خروج از حساب' : 'Logout / Exit'}
        </button>
        {adminRest && <RestaurantAdmin restaurant={adminRest} lang={lang} />}
      </div>
    );
  }

  // Super Admin View Router
  if (currentPath === '/superadmin') {
    if (!currentUser || currentUser.role !== 'super_admin') {
      return (
        <div className="w-full min-h-screen bg-slate-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 md:p-8 w-full max-w-sm shadow-xl text-center">
            <Shield className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-950 mb-1">
              {lang === 'fa' ? 'مدیریت ارشد سامانه (SaaS)' : 'Super Admin Core'}
            </h2>
            <p className="text-xs text-slate-500 mb-6">
              {lang === 'fa' ? 'ورود به پنل مدیریت کلان و تحلیل‌های سراسری پلتفرم' : 'Protected SaaS master telemetry portal'}
            </p>

            {authError && (
              <div className="mb-4 text-xs bg-rose-50 border border-rose-100 text-rose-800 p-2.5 rounded-xl">
                {authError === 'Authentication failed' && lang === 'fa' ? 'ایمیل وارد شده معتبر نمی‌باشد' : authError}
              </div>
            )}

            <form onSubmit={handlePortalLogin} className="space-y-4">
              <input
                type="email"
                required
                placeholder="admin@quickmenu.com"
                value={authEmail}
                onChange={e => setAuthEmail(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl outline-none text-xs text-center"
              />
              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer hover:bg-indigo-700 transition-all"
              >
                {authLoading ? '...' : (lang === 'fa' ? 'ورود به سیستم مرکزی' : 'Access Core')}
              </button>
            </form>

            <button
              onClick={() => navigateTo('/')}
              className="mt-4 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              {lang === 'fa' ? '← بازگشت به پورتال اصلی' : '← Back to Sandbox'}
            </button>
          </div>
        </div>
      );
    }

    return (
      <div className="relative">
        <button
          onClick={handleLogout}
          className="absolute top-8 right-8 z-50 px-3.5 py-1.5 text-xs font-semibold bg-slate-100 border border-slate-200 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer transition-all"
        >
          {lang === 'fa' ? 'خروج از حساب کاربری' : 'Logout / Exit'}
        </button>
        <SuperAdmin lang={lang} />
      </div>
    );
  }

  // ----------------------------------------------------
  // PRIMARY PORTAL HUB (Bento Grid Workspace)
  // ----------------------------------------------------
  return (
    <div className="w-full min-h-screen bg-slate-50 text-slate-800 selection:bg-indigo-100" dir="rtl">
      {/* Top Banner */}
      <header className="bg-white border-b border-slate-100/80 sticky top-0 z-30 shadow-xs">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-extrabold text-xl shadow-lg shadow-indigo-600/30">
              Q
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900 tracking-tight">سامانه منوی دیجیتال کوئیک‌منو (SaaS)</h1>
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">شبیه‌ساز چندرستورانی و سفارش‌گیر</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={triggerPWAInstall}
              className="px-3.5 py-2 text-xs font-semibold bg-indigo-50 hover:bg-indigo-100/80 border border-indigo-100/50 text-indigo-700 rounded-full cursor-pointer transition-all flex items-center gap-1.5"
            >
              <AppWindow className="w-3.5 h-3.5" />
              <span>نصب وب‌اپلیکیشن (PWA)</span>
            </button>
            <LanguageSwitcher currentLang={lang} onLanguageChange={setLang} />
          </div>
        </div>
      </header>

      {/* Main Sandbox Container */}
      <main className="max-w-6xl mx-auto px-6 py-12 space-y-12">
        {/* Intro */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="bg-indigo-600/10 text-indigo-700 font-extrabold text-[10px] px-3 py-1 rounded-full uppercase tracking-widest inline-block">
            ارائه فنی پیشرفته Full-Stack و UI/UX
          </span>
          <h2 className="text-2xl md:text-4xl font-extrabold text-slate-950 tracking-tight">
            محیط یکپارچه تست و شبیه‌سازی منوی دیجیتال QR
          </h2>
          <p className="text-xs md:text-sm text-slate-500 leading-relaxed">
            به اکوسیستم پیشرفته کوئیک‌منو خوش آمدید. این پورتال تعاملی به شما امکان می‌دهد تا به سادگی و به صورت لحظه‌ای بین بخش‌های مختلف سیستم جابجا شوید؛ از مشتریانی که با اسکن کد QR روی میز کباب یا برگر سفارش می‌دهند، تا سرآشپزان آشپزخانه و مدیران ارشد پلتفرم.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Box 0: Ararat Premium PWA Digital Menu */}
          <div
            onClick={() => window.location.href = '/pwa-menu/index.html'}
            className="md:col-span-12 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-amber-500/20 rounded-3xl p-6 md:p-8 shadow-xl hover:shadow-2xl hover:border-amber-400/40 hover:-translate-y-1 transition-all duration-300 cursor-pointer group text-right flex flex-col md:flex-row items-center justify-between gap-6"
          >
            <div className="flex flex-col md:flex-row items-center gap-5">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-all duration-300">
                <Sparkles className="w-8 h-8" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1 justify-center md:justify-start">
                  <h3 className="text-xl font-black text-amber-300 flex items-center gap-1.5 group-hover:text-amber-200 transition-colors">
                    وب‌اپلیکیشن منوی دیجیتال آرارات (PWA ایستا)
                  </h3>
                  <span className="bg-amber-400/10 border border-amber-400/30 text-amber-400 font-extrabold text-[10px] px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    پیشنهاد ویژه (PWA)
                  </span>
                </div>
                <span className="text-xs uppercase font-bold text-slate-300 tracking-wider block">ساخته شده با HTML، CSS3، Bootstrap 5 و JS محلی</span>
                <p className="text-xs text-slate-400 mt-2.5 leading-relaxed max-w-2xl">
                  منوی مستقل لوکس شیشه‌ای (Glassmorphism) طراحی شده با الهام از اپل و استرایپ. این منو کاملاً بدون دیتابیس بوده و با ویرایش فایل ساده <code className="bg-slate-950 px-1 py-0.5 rounded text-amber-400">menu.json</code> به آسانی شخصی‌سازی می‌شود. ایده آل برای میزبانی در GitHub Pages و اسکن بارکد QR میزها با احساس یک اپلیکیشن بومی.
                </p>
              </div>
            </div>
            <div className="shrink-0 flex items-center gap-2 bg-amber-400/10 hover:bg-amber-400/25 border border-amber-400/30 text-amber-300 font-bold px-5 py-3 rounded-full transition-all">
              <span>ورود به منو</span>
              <ChevronRight className="w-5 h-5 -rotate-180" />
            </div>
          </div>

          {/* Box 1: Shandiz Customer View */}
          <div
            onClick={() => navigateTo('/r/shandiz', '?table=2')}
            className="md:col-span-6 bg-white border border-slate-100 rounded-3xl p-6 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group text-right"
          >
            <div className="w-12 h-12 rounded-2xl bg-violet-50 text-violet-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-all duration-300">
              <QrCode className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-950 flex items-center gap-1.5 group-hover:text-indigo-600 transition-colors">
              <span>رستوران سنتی شاندیز</span>
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:-translate-x-1 transition-all" />
            </h3>
            <span className="text-[10px] uppercase font-bold text-violet-600 tracking-wider block mt-1">تجربه کاملاً فارسی و راست‌چین (RTL)</span>
            <p className="text-xs text-slate-500 mt-3 leading-relaxed">
              شبیه‌ساز سفارش‌دهی با اسکن بارکد برای رستوران سنتی شاندیز. دارای کباب‌های اصیل ایرانی، دوغ زعفرانی، باشگاه مشتریان، شناسایی خودکار میز شماره ۲، کد تخفیف (OFF10) و ثبت بازخورد.
            </p>
          </div>

          {/* Box 2: Burger Lab Customer View */}
          <div
            onClick={() => navigateTo('/r/burgerlab', '?table=T1')}
            className="md:col-span-6 bg-white border border-slate-100 rounded-3xl p-6 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group text-right"
          >
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-all duration-300">
              <Utensils className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-950 flex items-center gap-1.5 group-hover:text-indigo-600 transition-colors">
              <span>رستوران برگر لب (Burger Lab)</span>
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:-translate-x-1 transition-all" />
            </h3>
            <span className="text-[10px] uppercase font-bold text-rose-600 tracking-wider block mt-1">تجربه منوی بین‌المللی برگر لب</span>
            <p className="text-xs text-slate-500 mt-3 leading-relaxed">
              برگرهای زغالی و دست‌ساز. طراحی فست‌فودی مدرن با همبرگرهای تخصصی، سیب‌زمینی سرخ‌کرده پنیری، شناسایی میز T1، سبد خرید و کد تخفیف فعال (WELCOME).
            </p>
          </div>

          {/* Box 3: Restaurant Admin Portal */}
          <div
            onClick={() => navigateTo('/admin')}
            className="md:col-span-4 bg-white border border-slate-100 rounded-3xl p-6 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group text-right"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-all duration-300">
              <Settings className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-950 flex items-center gap-1.5 group-hover:text-indigo-600 transition-colors">
              <span>پنل مدیریت رستوران</span>
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:-translate-x-1 transition-all" />
            </h3>
            <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">
              مدیریت لوگو و برند، دسته‌ها، آیتم‌های منو، قیمت‌ها، کدهای تخفیف، مدیریت میزهای فعال و دانلود تابلوی بارکد QR اختصاصی میزها.
            </p>
          </div>

          {/* Box 4: Kitchen Dashboard */}
          <div
            onClick={() => navigateTo('/kitchen')}
            className="md:col-span-4 bg-white border border-slate-100 rounded-3xl p-6 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group text-right"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-all duration-300">
              <ChefHat className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-950 flex items-center gap-1.5 group-hover:text-indigo-600 transition-colors">
              <span>داشبورد سفارشات آشپزخانه (KDS)</span>
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:-translate-x-1 transition-all" />
            </h3>
            <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">
              سامانه نمایش سفارش‌های دریافتی برای سرآشپزها. پیگیری زمان پخت، کنترل آیتم‌های آماده شده و به‌روزرسانی لحظه‌ای وضعیت سفارشات.
            </p>
          </div>

          {/* Box 5: SaaS Super Admin Panel */}
          <div
            onClick={() => navigateTo('/superadmin')}
            className="md:col-span-4 bg-white border border-slate-100 rounded-3xl p-6 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group text-right"
          >
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-all duration-300">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-950 flex items-center gap-1.5 group-hover:text-indigo-600 transition-colors">
              <span>پنل مدیریت ارشد سیستم (SaaS)</span>
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:-translate-x-1 transition-all" />
            </h3>
            <p className="text-xs text-slate-500 mt-2.5 leading-relaxed">
              داشبورد کلان پلتفرم. مشاهده آمار کلی، راه‌اندازی و ثبت فوری رستوران‌های جدید و مانیتورینگ وضعیت اشتراک‌های فعال.
            </p>
          </div>
        </div>

        {/* Feature Highlights Grid */}
        <div className="pt-8 border-t border-slate-200/50">
          <h3 className="text-base font-extrabold text-slate-950 mb-6 text-center">ویژگی‌ها و فناوری‌های پیاده‌سازی شده</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-xs text-slate-600 text-right">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1.5">
              <strong className="text-slate-900 block font-bold">طراحی ۱۰۰٪ واکنش‌گرا و وب‌اپلیکیشن (PWA)</strong>
              <p className="leading-relaxed text-slate-500">
                رابط کاربری روان مشابه اپلیکیشن‌های بومی اندروید و iOS، بهینه‌سازی شده برای مرورگرهای درون‌برنامه‌ای اسکنر دوربین گوشی.
              </p>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1.5">
              <strong className="text-slate-900 block font-bold">پشتیبانی بومی از زبان شیرین فارسی</strong>
              <p className="leading-relaxed text-slate-500">
                تنظیم خودکار متون به صورت کاملاً راست‌چین (RTL)، مبالغ ریالی/تومانی، دسته‌بندی‌ها و دکمه‌های کاملاً فارسی.
              </p>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1.5">
              <strong className="text-slate-900 block font-bold">همگام‌سازی و پایگاه داده زنده سرور</strong>
              <p className="leading-relaxed text-slate-500">
                پشتیبان سرور ابری تمام تغییرات و سفارشات شما را ثبت می‌کند و وضعیت سفارشات را به صورت لحظه‌ای به آشپزخانه و مشتری اعلام می‌کند.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
