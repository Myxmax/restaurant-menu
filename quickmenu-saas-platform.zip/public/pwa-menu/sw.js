const CACHE_NAME = 'ararat-pwa-cache-v1';
const ASSETS_TO_CACHE = [
  '/pwa-menu/',
  '/pwa-menu/index.html',
  '/pwa-menu/css/style.css',
  '/pwa-menu/js/app.js',
  '/pwa-menu/menu.json',
  '/pwa-menu/manifest.json'
];

// Install Event
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[Service Worker] Pre-caching static assets');
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Activate Event
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.map(key => {
          if (key !== CACHE_NAME) {
            console.log('[Service Worker] Removing old cache:', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch Event (Network-First Fallback with Static Caching)
self.addEventListener('fetch', event => {
  // Avoid interception for non-GET requests or different domains
  if (event.request.method !== 'GET') return;

  event.respondWith(
    fetch(event.request)
      .then(networkResponse => {
        // Cache successful requests dynamically
        if (networkResponse.status === 200 && event.request.url.startsWith(self.location.origin)) {
          const cacheCopy = networkResponse.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, cacheCopy);
          });
        }
        return networkResponse;
      })
      .catch(() => {
        // Fallback to cache if network fails
        return caches.match(event.request).then(cachedResponse => {
          if (cachedResponse) {
            return cachedResponse;
          }
          // Fallback if resource is totally missing offline (e.g. external images)
          if (event.request.headers.get('accept').includes('text/html')) {
            return caches.match('/pwa-menu/index.html');
          }
        });
      })
  );
});
