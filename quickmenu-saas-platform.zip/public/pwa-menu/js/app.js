// Ararat Premium PWA Digital Menu - Core Logic
let menuData = null;
let currentLanguage = 'fa'; // Default to Persian
let currentCategory = 'featured';
let searchQuery = '';
let deferredPrompt = null;

// Translation resources
const translations = {
  fa: {
    searchPlaceholder: "جستجو در منو (مثلا: کپل برگر، پیتزا، سیب‌زمینی)...",
    featuredTitle: "✨ پیشنهادهای ویژه سرآشپز سعید کپل",
    featuredSubtitle: "لذیذترین و پرملات‌ترین طعم‌های منتخب فست فود سعید کپل",
    bestSellersTitle: "🔥 پرفروش‌ترین‌های سعید کپل",
    allFoodsTitle: "منوی غذا و نوشیدنی‌ها",
    ingredients: "ترکیبات اصلی:",
    workingHours: "ساعت کاری",
    address: "نشانی فست فود",
    phone: "تلفن تماس",
    socials: "راه‌های ارتباطی و سفارش",
    location: "مسیریابی روی نقشه",
    whatsapp: "ارتباط مستقیم در واتس‌اپ",
    instagram: "صفحه اینستاگرام فست فود سعید کپل",
    call: "تماس تلفنی و سفارش سریع",
    installTitle: "نصب وب‌اپلیکیشن (PWA)",
    installDesc: "برای دسترسی سریع و بدون نیاز به نصب از بازار یا استور، این منو را به صفحه اصلی گوشی خود اضافه کنید.",
    installBtn: "نصب فوری منو",
    close: "بستن",
    noResults: "هیچ آیتمی با جستجوی شما مطابقت ندارد! 😔",
    tomans: "تومان",
    currencySymbol: "تومان",
    specialBadge: "پیشنهاد ویژه",
    bestBadge: "پرفروش‌ترین",
    newBadge: "جدید",
    chefBadge: "پیشنهاد سرآشپز"
  },
  en: {
    searchPlaceholder: "Search menu (e.g. Kopol Burger, Pizza, Fries)...",
    featuredTitle: "✨ Chef Saeid's Special Recommendations",
    featuredSubtitle: "The most delicious, hand-picked tastes of Saeid Kopol Fast Food",
    bestSellersTitle: "🔥 Weekly Best Sellers",
    allFoodsTitle: "Food & Drinks Menu",
    ingredients: "Key Ingredients:",
    workingHours: "Working Hours",
    address: "Location Address",
    phone: "Contact Phone",
    socials: "Social & Contact Options",
    location: "Navigate on Google Maps",
    whatsapp: "Direct WhatsApp Message",
    instagram: "Saeid Kopol Instagram Profile",
    call: "Direct Call & Order Placement",
    installTitle: "Install Web App (PWA)",
    installDesc: "Add our digital menu to your home screen for high speed and offline access.",
    installBtn: "Install Now",
    close: "Close",
    noResults: "No menu items match your search query! 😔",
    tomans: "Toman",
    currencySymbol: "Toman",
    specialBadge: "Special Offer",
    bestBadge: "Best Seller",
    newBadge: "New",
    chefBadge: "Chef Recommended"
  }
};

// Format Currency dynamically
function formatCurrency(price) {
  const locale = currentLanguage === 'fa' ? 'fa-IR' : 'en-US';
  const formatter = new Intl.NumberFormat(locale, {
    useGrouping: true
  });
  return formatter.format(price);
}

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  // Set default theme from localStorage or system
  const savedTheme = localStorage.getItem('ararat_theme') || 'dark';
  setTheme(savedTheme);

  // Load configuration and items from local JSON
  fetchMenuData();

  // Setup Event Listeners
  setupEventListeners();

  // Register PWA Service Worker
  registerServiceWorker();
});

// Set Theme function
function setTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('ararat_theme', theme);
  
  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) {
    if (theme === 'light') {
      themeBtn.innerHTML = '<i class="bi bi-moon-stars-fill"></i>';
    } else {
      themeBtn.innerHTML = '<i class="bi bi-sun-fill"></i>';
    }
  }
}

// Set Language function
function setLanguage(lang) {
  currentLanguage = lang;
  localStorage.setItem('ararat_lang', lang);
  
  // Set Direction & Lang tags
  document.documentElement.setAttribute('lang', lang);
  document.documentElement.setAttribute('dir', lang === 'fa' ? 'rtl' : 'ltr');
  
  // Update static localized elements
  updateLocalizedText();

  // Rerender Categories and Items
  if (menuData) {
    renderCategories();
    renderBestSellers();
    renderMenuItems();
  }
}

// Fetch Menu Data from JSON
async function fetchMenuData() {
  try {
    const response = await fetch('./menu.json');
    if (!response.ok) throw new Error('Failed to load menu JSON');
    menuData = await response.json();
    
    // Apply default language
    const savedLang = localStorage.getItem('ararat_lang') || 'fa';
    setLanguage(savedLang);

    // Initial render
    renderRestaurantInfo();
    renderImageGallery();
  } catch (error) {
    console.error('Error fetching menu details:', error);
    showNotification('خطا در بارگذاری منوی دیجیتال', 'error');
  }
}

// Update Localized Strings in UI
function updateLocalizedText() {
  const t = translations[currentLanguage];
  
  // Search placeholder
  const searchInput = document.getElementById('menu-search');
  if (searchInput) {
    searchInput.placeholder = t.searchPlaceholder;
  }

  // Headings
  const featuredTitleEl = document.getElementById('featured-title-text');
  if (featuredTitleEl) featuredTitleEl.textContent = t.featuredTitle;

  const featuredSubEl = document.getElementById('featured-sub-text');
  if (featuredSubEl) featuredSubEl.textContent = t.featuredSubtitle;

  const bestSellersEl = document.getElementById('bestsellers-title-text');
  if (bestSellersEl) bestSellersEl.textContent = t.bestSellersTitle;

  const restaurantAddressLabel = document.getElementById('lbl-address');
  if (restaurantAddressLabel) restaurantAddressLabel.textContent = t.address;

  const restaurantHoursLabel = document.getElementById('lbl-hours');
  if (restaurantHoursLabel) restaurantHoursLabel.textContent = t.workingHours;

  const restaurantPhoneLabel = document.getElementById('lbl-phone');
  if (restaurantPhoneLabel) restaurantPhoneLabel.textContent = t.phone;

  const restaurantSocialsLabel = document.getElementById('lbl-socials');
  if (restaurantSocialsLabel) restaurantSocialsLabel.textContent = t.socials;

  const lblGallery = document.getElementById('lbl-gallery');
  if (lblGallery) lblGallery.textContent = currentLanguage === 'fa' ? '📸 گالری تصاویر رستوران' : '📸 Ararat Atmosphere Gallery';

  // Modal static texts
  const closeBtns = document.querySelectorAll('.btn-close-modal');
  closeBtns.forEach(btn => btn.textContent = t.close);

  // PWA banner text
  const pwaTitle = document.getElementById('pwa-title');
  if (pwaTitle) pwaTitle.textContent = t.installTitle;

  const pwaDesc = document.getElementById('pwa-desc');
  if (pwaDesc) pwaDesc.textContent = t.installDesc;

  const pwaBtn = document.getElementById('pwa-install-btn');
  if (pwaBtn) pwaBtn.textContent = t.installBtn;

  const pwaClose = document.getElementById('pwa-close-btn');
  if (pwaClose) pwaClose.textContent = t.close;
}

// Render Restaurant Details
function renderRestaurantInfo() {
  if (!menuData || !menuData.restaurant) return;
  const rest = menuData.restaurant;

  // Header Cover and Logo
  const bannerImg = document.getElementById('restaurant-banner');
  if (bannerImg) bannerImg.src = rest.banner;

  const logoImg = document.getElementById('restaurant-logo');
  if (logoImg) logoImg.src = rest.logo;

  // Restaurant Titles
  const titleEl = document.getElementById('restaurant-title');
  if (titleEl) titleEl.textContent = currentLanguage === 'fa' ? rest.nameFa : rest.name;

  const descEl = document.getElementById('restaurant-desc');
  if (descEl) descEl.textContent = currentLanguage === 'fa' ? rest.descriptionFa : rest.description;

  // Card Contacts
  const addressText = document.getElementById('restaurant-address-text');
  if (addressText) addressText.textContent = currentLanguage === 'fa' ? rest.addressFa : rest.address;

  const hoursText = document.getElementById('restaurant-hours-text');
  if (hoursText) hoursText.textContent = currentLanguage === 'fa' ? rest.workingHoursFa : rest.workingHours;

  const phoneText = document.getElementById('restaurant-phone-text');
  if (phoneText) phoneText.textContent = currentLanguage === 'fa' ? rest.phoneDisplay : rest.phone;

  // Links & Call Triggers
  const callBtn = document.getElementById('call-btn');
  if (callBtn) {
    callBtn.href = `tel:${rest.phone}`;
    callBtn.innerHTML = `<span class="contact-icon"><i class="bi bi-telephone-outbound-fill"></i></span><div><strong>${currentLanguage === 'fa' ? 'تماس مستقیم و رزرو' : 'Direct Call'}</strong><br><small class="text-muted font-inter">${rest.phone}</small></div>`;
  }

  const whatsappBtn = document.getElementById('whatsapp-btn');
  if (whatsappBtn) {
    whatsappBtn.href = `https://wa.me/${rest.whatsapp}`;
    whatsappBtn.innerHTML = `<span class="contact-icon text-success" style="background: rgba(37,211,102,0.15)"><i class="bi bi-whatsapp"></i></span><div><strong>${currentLanguage === 'fa' ? 'پیام در واتس‌اپ' : 'WhatsApp Contact'}</strong><br><small class="text-muted font-inter">${rest.whatsappDisplay}</small></div>`;
  }

  const instagramBtn = document.getElementById('instagram-btn');
  if (instagramBtn) {
    instagramBtn.href = `https://instagram.com/${rest.instagram}`;
    instagramBtn.innerHTML = `<span class="contact-icon text-danger" style="background: rgba(225,48,108,0.15)"><i class="bi bi-instagram"></i></span><div><strong>${currentLanguage === 'fa' ? 'اینستاگرام آرارات' : 'Instagram Page'}</strong><br><small class="text-muted">@${rest.instagram}</small></div>`;
  }

  const mapBtn = document.getElementById('map-btn');
  if (mapBtn) {
    mapBtn.href = rest.location;
    mapBtn.innerHTML = `<span class="contact-icon text-info" style="background: rgba(13,110,253,0.15)"><i class="bi bi-geo-alt-fill"></i></span><div><strong>${currentLanguage === 'fa' ? 'مسیریابی روی نقشه بلد/گوگل' : 'Google Maps Directions'}</strong><br><small class="text-muted">${currentLanguage === 'fa' ? 'نمایش لوکیشن دقیق' : 'Show full address directions'}</small></div>`;
  }

  // Floating speed dials
  const floatCall = document.getElementById('float-call');
  if (floatCall) floatCall.href = `tel:${rest.phone}`;

  const floatWa = document.getElementById('float-wa');
  if (floatWa) floatWa.href = `https://wa.me/${rest.whatsapp}`;
}

// Render Categories Tab Bar
function renderCategories() {
  if (!menuData || !menuData.categories) return;
  const categoriesList = document.getElementById('categories-list');
  if (!categoriesList) return;

  categoriesList.innerHTML = '';
  menuData.categories.forEach(cat => {
    const tabBtn = document.createElement('button');
    tabBtn.className = `category-tab ${currentCategory === cat.id ? 'active' : ''}`;
    tabBtn.setAttribute('data-category', cat.id);
    
    const catName = currentLanguage === 'fa' ? cat.nameFa : cat.name;
    tabBtn.innerHTML = `<i class="bi ${cat.icon}"></i> <span>${catName}</span>`;
    
    tabBtn.addEventListener('click', () => {
      // Toggle active states
      document.querySelectorAll('.category-tab').forEach(btn => btn.classList.remove('active'));
      tabBtn.classList.add('active');
      
      currentCategory = cat.id;
      
      // Filter list with smooth fade transition
      const listContainer = document.getElementById('menu-items-list');
      if (listContainer) {
        listContainer.style.opacity = '0';
        setTimeout(() => {
          renderMenuItems();
          listContainer.style.opacity = '1';
        }, 150);
      }
    });

    categoriesList.appendChild(tabBtn);
  });
}

// Helper to render multiple badges dynamically
function renderCardBadges(item) {
  const t = translations[currentLanguage];
  let badgesHTML = '';
  
  if (item.isBestSeller) {
    badgesHTML += `<span class="custom-badge badge-bestseller"><i class="bi bi-fire"></i> ${t.bestBadge}</span>`;
  }
  if (item.isNew) {
    badgesHTML += `<span class="custom-badge badge-new"><i class="bi bi-sparkles"></i> ${t.newBadge}</span>`;
  }
  if (item.isChefRecommended) {
    badgesHTML += `<span class="custom-badge badge-chef"><i class="bi bi-hand-thumbs-up-fill"></i> ${t.chefBadge}</span>`;
  }
  if (item.isFeatured && currentCategory !== 'featured') {
    badgesHTML += `<span class="custom-badge badge-featured"><i class="bi bi-gift-fill"></i> ${t.specialBadge}</span>`;
  }

  if (badgesHTML) {
    return `<div class="card-badges-container">${badgesHTML}</div>`;
  }
  return '';
}

// Render Top Best Sellers Carousel
function renderBestSellers() {
  if (!menuData || !menuData.items) return;
  const carouselTrack = document.getElementById('best-sellers-track');
  if (!carouselTrack) return;

  carouselTrack.innerHTML = '';
  const bestSellers = menuData.items.filter(item => item.isBestSeller);

  bestSellers.forEach(item => {
    const card = document.createElement('div');
    card.className = 'glass-card carousel-card overflow-hidden p-2';
    
    const name = currentLanguage === 'fa' ? item.nameFa : item.name;
    const desc = currentLanguage === 'fa' ? item.descriptionFa : item.description;

    card.innerHTML = `
      <div class="food-card-img-wrapper" style="height: 140px; border-radius: 12px;">
        <img src="${item.image}" alt="${name}" class="food-card-img" loading="lazy">
        ${renderCardBadges(item)}
      </div>
      <div class="p-2 text-start mt-2">
        <h4 class="text-sm font-bold mb-1 text-truncate">${name}</h4>
        <p class="text-[11px] text-muted text-truncate mb-2">${desc}</p>
        <div class="d-flex justify-between align-items-center">
          <span class="price-tag font-inter text-sm font-bold">${formatCurrency(item.price)}</span>
          <button class="btn btn-sm py-1 px-2 text-white bg-dark border-glass rounded-pill" onclick="openDetailsModal('${item.id}')">
            <i class="bi bi-eye"></i>
          </button>
        </div>
      </div>
    `;

    carouselTrack.appendChild(card);
  });
}

// Render Main Menu Items list (Supports Categories and Searches)
function renderMenuItems() {
  if (!menuData || !menuData.items) return;
  const listContainer = document.getElementById('menu-items-list');
  const sectionTitle = document.getElementById('main-menu-section-title');
  if (!listContainer) return;

  listContainer.innerHTML = '';
  const t = translations[currentLanguage];

  // Map category ID to Title
  const matchedCat = menuData.categories.find(c => c.id === currentCategory);
  if (sectionTitle && matchedCat) {
    sectionTitle.textContent = currentLanguage === 'fa' ? matchedCat.nameFa : matchedCat.name;
  }

  // Filter items by category OR featured
  let filteredItems = menuData.items;
  
  if (currentCategory === 'featured') {
    // Featured category lists all items that are isFeatured
    filteredItems = menuData.items.filter(item => item.isFeatured);
  } else {
    // Filter by specific category tab
    filteredItems = menuData.items.filter(item => item.category === currentCategory);
  }

  // Apply search query filter if typing
  if (searchQuery.trim() !== '') {
    const q = searchQuery.toLowerCase().trim();
    filteredItems = menuData.items.filter(item => {
      const name = item.name.toLowerCase();
      const nameFa = item.nameFa.toLowerCase();
      const desc = item.description.toLowerCase();
      const descFa = item.descriptionFa.toLowerCase();
      const ingreds = item.ingredients.map(i => i.toLowerCase()).join(' ');
      const ingredsFa = item.ingredientsFa.map(i => i.toLowerCase()).join(' ');
      
      return name.includes(q) || nameFa.includes(q) || desc.includes(q) || descFa.includes(q) || ingreds.includes(q) || ingredsFa.includes(q);
    });

    if (sectionTitle) {
      sectionTitle.textContent = currentLanguage === 'fa' ? 'نتایج جستجو' : 'Search Results';
    }
  }

  // Show Empty Placeholder if no results
  if (filteredItems.length === 0) {
    listContainer.innerHTML = `
      <div class="col-12 text-center py-5">
        <i class="bi bi-emoji-frown text-muted" style="font-size: 3rem;"></i>
        <p class="text-muted mt-3 mb-0">${t.noResults}</p>
      </div>
    `;
    return;
  }

  // Render list cards (Widescreen flex grid responsive)
  filteredItems.forEach((item, index) => {
    const cardCol = document.createElement('div');
    cardCol.className = 'col-md-6 col-lg-4 animate-slide-up';
    cardCol.style.animationDelay = `${(index % 6) * 0.08}s`;

    const name = currentLanguage === 'fa' ? item.nameFa : item.name;
    const desc = currentLanguage === 'fa' ? item.descriptionFa : item.description;

    cardCol.innerHTML = `
      <div class="glass-card overflow-hidden h-100 d-flex flex-column cursor-pointer" onclick="openDetailsModal('${item.id}')">
        <div class="food-card-img-wrapper">
          <img src="${item.image}" alt="${name}" class="food-card-img" loading="lazy">
          ${renderCardBadges(item)}
        </div>
        <div class="p-4 flex-grow-1 text-start d-flex flex-column justify-between">
          <div>
            <h4 class="text-base font-bold text-white mb-2">${name}</h4>
            <p class="text-xs text-muted mb-3 line-clamp-2" style="min-height: 36px;">${desc}</p>
          </div>
          <div class="d-flex justify-between align-items-center mt-2">
            <span class="price-tag">${formatCurrency(item.price)}</span>
            <span class="btn btn-sm py-1.5 px-3 rounded-full text-xs font-semibold text-white bg-dark border-glass">
              ${currentLanguage === 'fa' ? 'مشاهده ترکیبات' : 'View ingredients'}
            </span>
          </div>
        </div>
      </div>
    `;

    listContainer.appendChild(cardCol);
  });
}

// Render Restaurant Image Gallery
function renderImageGallery() {
  if (!menuData || !menuData.gallery) return;
  const galleryGrid = document.getElementById('gallery-items-grid');
  if (!galleryGrid) return;

  galleryGrid.innerHTML = '';
  menuData.gallery.forEach(imgUrl => {
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.innerHTML = `<img src="${imgUrl}" alt="Restaurant Atmosphere" loading="lazy">`;
    item.addEventListener('click', () => {
      openLightbox(imgUrl);
    });
    galleryGrid.appendChild(item);
  });
}

// Open Food Details Apple-styled Modal
window.openDetailsModal = function(itemId) {
  if (!menuData || !menuData.items) return;
  const item = menuData.items.find(i => i.id === itemId);
  if (!item) return;

  const t = translations[currentLanguage];
  const name = currentLanguage === 'fa' ? item.nameFa : item.name;
  const desc = currentLanguage === 'fa' ? item.descriptionFa : item.description;
  const ingreds = currentLanguage === 'fa' ? item.ingredientsFa : item.ingredients;

  // Set Modal fields
  document.getElementById('modal-item-name').textContent = name;
  document.getElementById('modal-item-img').src = item.image;
  document.getElementById('modal-item-desc').textContent = desc;
  document.getElementById('modal-item-price').textContent = formatCurrency(item.price);
  
  // Render Ingredients
  const ingredContainer = document.getElementById('modal-item-ingredients');
  ingredContainer.innerHTML = '';
  
  // Ingredients Label
  document.getElementById('modal-ingredients-label').textContent = t.ingredients;

  ingreds.forEach(ing => {
    const badge = document.createElement('span');
    badge.className = 'ingredient-badge me-2 mb-2';
    badge.textContent = ing;
    ingredContainer.appendChild(badge);
  });

  // Open Bootstrap Modal
  const modalEl = document.getElementById('foodDetailsModal');
  const modal = new bootstrap.Modal(modalEl);
  modal.show();
};

// Open Image Lightbox
function openLightbox(imgUrl) {
  const lightboxImg = document.getElementById('lightbox-img');
  if (lightboxImg) {
    lightboxImg.src = imgUrl;
    const lightboxModal = new bootstrap.Modal(document.getElementById('lightboxModal'));
    lightboxModal.show();
  }
}

// Setup Event Listeners
function setupEventListeners() {
  // Theme Switch Toggle
  const themeToggle = document.getElementById('theme-toggle-btn');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const currentTheme = document.documentElement.getAttribute('data-theme');
      setTheme(currentTheme === 'light' ? 'dark' : 'light');
    });
  }

  // Language Switch Toggle
  const langToggle = document.getElementById('lang-toggle-btn');
  if (langToggle) {
    langToggle.addEventListener('click', () => {
      setLanguage(currentLanguage === 'fa' ? 'en' : 'fa');
    });
  }

  // Live Search Input handler
  const searchInput = document.getElementById('menu-search');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      renderMenuItems();
    });
  }

  // Close PWA banner manually
  const pwaClose = document.getElementById('pwa-close-btn');
  const pwaPromo = document.getElementById('pwa-promo');
  if (pwaClose && pwaPromo) {
    pwaClose.addEventListener('click', () => {
      pwaPromo.classList.remove('show');
    });
  }
}

// PWA Service Worker Registration
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js')
        .then(reg => console.log('[Service Worker] Registered successfully:', reg.scope))
        .catch(err => console.error('[Service Worker] Registration failed:', err));
    });
  }

  // Listen for standalone mode install trigger
  window.addEventListener('beforeinstallprompt', (e) => {
    // Prevent standard Chrome mini-bar from showing
    e.preventDefault();
    deferredPrompt = e;
    
    // Show premium sliding PWA install promo bar after 4 seconds
    setTimeout(() => {
      const pwaPromo = document.getElementById('pwa-promo');
      if (pwaPromo) pwaPromo.classList.add('show');
    }, 4000);
  });

  // Setup click for custom Install Button
  const installBtn = document.getElementById('pwa-install-btn');
  if (installBtn) {
    installBtn.addEventListener('click', () => {
      const pwaPromo = document.getElementById('pwa-promo');
      if (pwaPromo) pwaPromo.classList.remove('show');
      
      if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
          if (choiceResult.outcome === 'accepted') {
            console.log('[PWA Installer] User accepted installation prompt');
          } else {
            console.log('[PWA Installer] User dismissed installation prompt');
          }
          deferredPrompt = null;
        });
      } else {
        // Fallback info for iOS / Safari users
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
        if (isIOS) {
          alert(currentLanguage === 'fa' 
            ? 'کاربر گرامی، برای نصب روی سیستم‌عامل iOS:\n۱. دکمه Share (اشتراک) را در پایین مرورگر سافاری بزنید.\n۲. گزینه Add to Home Screen (افزودن به صفحه اصلی) را انتخاب کنید.'
            : 'To install on iOS:\n1. Tap the Share button in Safari.\n2. Select "Add to Home Screen" from the sheet.'
          );
        } else {
          alert(currentLanguage === 'fa'
            ? 'وب‌اپلیکیشن هم‌اکنون به عنوان اپ فعال نصب شده یا مرورگر شما در حال حاضر از نصب مستقیم پشتیبانی نمی‌کند.'
            : 'Web App is already installed or direct browser installation is not supported.'
          );
        }
      }
    });
  }
}

// Quick UI Notification
function showNotification(msg, type = 'success') {
  alert(msg);
}
