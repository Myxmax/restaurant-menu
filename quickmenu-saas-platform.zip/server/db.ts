import fs from 'fs';
import path from 'path';
import { Restaurant, Category, MenuItem, Table, Order, Review, Coupon, User } from '../src/types';

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'db.json');

export interface DatabaseSchema {
  users: User[];
  restaurants: Restaurant[];
  categories: Category[];
  menuItems: MenuItem[];
  tables: Table[];
  orders: Order[];
  reviews: Review[];
  coupons: Coupon[];
}

const defaultDatabase: DatabaseSchema = {
  users: [
    {
      id: 'usr_super',
      email: 'admin@quickmenu.com',
      role: 'super_admin',
      name: 'Sina Admin',
      createdAt: '2026-07-01T12:00:00Z'
    },
    {
      id: 'usr_shandiz',
      email: 'shandiz@quickmenu.com',
      role: 'restaurant_admin',
      restaurantId: 'rest_shandiz',
      name: 'Shandiz Manager',
      createdAt: '2026-07-02T12:00:00Z'
    },
    {
      id: 'usr_burger',
      email: 'burger@quickmenu.com',
      role: 'restaurant_admin',
      restaurantId: 'rest_burger',
      name: 'Burger Lab Manager',
      createdAt: '2026-07-02T12:00:00Z'
    },
    {
      id: 'usr_kitchen_burger',
      email: 'kitchen@burger.com',
      role: 'kitchen_staff',
      restaurantId: 'rest_burger',
      name: 'Burger Lab Chef',
      createdAt: '2026-07-03T12:00:00Z'
    }
  ],
  restaurants: [
    {
      id: 'rest_shandiz',
      name: 'Shandiz Restaurant',
      nameFa: 'رستوران شاندیز',
      slug: 'shandiz',
      description: 'Authentic Persian culinary experience with premium kebabs and traditional dishes.',
      descriptionFa: 'تجربه اصیل غذاهای سنتی ایرانی، کباب‌های ممتاز و دیس‌های سنتی.',
      logo: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=150&h=150&q=80',
      banner: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&h=400&q=80',
      primaryColor: '#8B5CF6', // violet-500
      accentColor: '#F59E0B', // amber-500
      address: 'No. 45, Valiasr St, Tehran, Iran',
      addressFa: 'تهران، خیابان ولیعصر، پلاک ۴۵',
      phone: '+98 21 8888 8888',
      workingHours: '12:00 PM - 11:30 PM',
      workingHoursFa: '۱۲:۰۰ ظهر تا ۱۱:۳۰ شب',
      subscriptionStatus: 'active',
      subscriptionExpiry: '2027-07-15T00:00:00Z',
      loyaltyConfig: {
        pointsPerDollar: 10,
        pointsThresholdForDiscount: 500,
        discountValue: 10
      },
      qrScansCount: 452
    },
    {
      id: 'rest_burger',
      name: 'Burger Lab',
      nameFa: 'برگر لب',
      slug: 'burgerlab',
      description: 'Gourmet artisanal burgers crafted with organic ingredients and house-made sauces.',
      descriptionFa: 'برگرهای دست‌ساز با مواد اولیه ارگانیک و سس‌های مخصوص خانه.',
      logo: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=150&h=150&q=80',
      banner: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&h=400&q=80',
      primaryColor: '#EF4444', // red-500
      accentColor: '#10B981', // emerald-500
      address: '7th Avenue, Food Street, Shiraz, Iran',
      addressFa: 'شیراز، خیابان غذا، نبش کوچه هفتم',
      phone: '+98 71 3333 3333',
      workingHours: '11:00 AM - Midnight',
      workingHoursFa: '۱۱:۰۰ صبح تا نیمه‌شب',
      subscriptionStatus: 'active',
      subscriptionExpiry: '2026-12-31T23:59:59Z',
      loyaltyConfig: {
        pointsPerDollar: 15,
        pointsThresholdForDiscount: 300,
        discountValue: 5
      },
      qrScansCount: 981
    }
  ],
  categories: [
    {
      id: 'cat_sh_1',
      restaurantId: 'rest_shandiz',
      name: 'Signature Kebabs',
      nameFa: 'کباب‌های مخصوص',
      icon: 'Flame',
      sortOrder: 1
    },
    {
      id: 'cat_sh_2',
      restaurantId: 'rest_shandiz',
      name: 'Traditional Starters',
      nameFa: 'پیش‌غذاهای سنتی',
      icon: 'Soup',
      sortOrder: 2
    },
    {
      id: 'cat_sh_3',
      restaurantId: 'rest_shandiz',
      name: 'Drinks & Desserts',
      nameFa: 'نوشیدنی و دسر',
      icon: 'GlassWater',
      sortOrder: 3
    },
    {
      id: 'cat_bu_1',
      restaurantId: 'rest_burger',
      name: 'Smash Burgers',
      nameFa: 'اسمش برگرها',
      icon: 'Flame',
      sortOrder: 1
    },
    {
      id: 'cat_bu_2',
      restaurantId: 'rest_burger',
      name: 'Loaded Fries',
      nameFa: 'سیب‌زمینی مخصوص',
      icon: 'Sparkles',
      sortOrder: 2
    },
    {
      id: 'cat_bu_3',
      restaurantId: 'rest_burger',
      name: 'Craft Beverages',
      nameFa: 'نوشیدنی‌های خنک',
      icon: 'Coffee',
      sortOrder: 3
    }
  ],
  menuItems: [
    {
      id: 'item_sh_101',
      restaurantId: 'rest_shandiz',
      categoryId: 'cat_sh_1',
      name: 'Shandiz Royal Kebab (Shashlik)',
      nameFa: 'شیشلیک مخصوص شاندیز',
      description: '600g of premium lamb chops marinated in onions and saffron, flame-grilled on skewers, served with saffron basmati rice.',
      descriptionFa: '۶۰۰ گرم دنده گوسفندی مرینیت شده در پیاز و زعفران فراوان، پخت روی زغال، همراه با برنج زعفرانی.',
      price: 24.50,
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&h=250&q=80',
      isAvailable: true,
      prepTimeMinutes: 25,
      calories: 850,
      isVegetarian: false,
      isSpicy: false,
      ratingsCount: 124,
      averageRating: 4.9
    },
    {
      id: 'item_sh_102',
      restaurantId: 'rest_shandiz',
      categoryId: 'cat_sh_1',
      name: 'Saffron Lamb Kubideh',
      nameFa: 'کباب کوبیده زعفرانی',
      description: 'Two skewers of premium minced lamb ground with fat, spices, and grated onions, served with butter and rice.',
      descriptionFa: 'دو سیخ کباب کوبیده گوسفندی اعلا با کره حیوانی، گوجه کبابی و برنج ایرانی.',
      price: 14.90,
      image: 'https://images.unsplash.com/photo-1514516345957-556ca7d90a29?auto=format&fit=crop&w=400&h=250&q=80',
      isAvailable: true,
      prepTimeMinutes: 15,
      calories: 680,
      isVegetarian: false,
      isSpicy: false,
      ratingsCount: 88,
      averageRating: 4.8
    },
    {
      id: 'item_sh_103',
      restaurantId: 'rest_shandiz',
      categoryId: 'cat_sh_2',
      name: 'Kashk-e Bademjan',
      nameFa: 'کشک بادمجان محلی',
      description: 'Roasted eggplants mashed with kashk (whey), caramelized mint, onions, garlic, and walnut chunks.',
      descriptionFa: 'بادمجان کبابی سرخ‌شده، کشک سابیده محلی، نعناع داغ، پیاز داغ، سیر داغ و گردو فراوان.',
      price: 7.50,
      image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&w=400&h=250&q=80',
      isAvailable: true,
      prepTimeMinutes: 10,
      calories: 320,
      isVegetarian: true,
      isSpicy: false,
      ratingsCount: 45,
      averageRating: 4.7
    },
    {
      id: 'item_sh_104',
      restaurantId: 'rest_shandiz',
      categoryId: 'cat_sh_3',
      name: 'Traditional Saffron Doogh',
      nameFa: 'دوغ محلی با نعناع و گل سرخ',
      description: 'Chilled yogurt drink seasoned with dried mint, crushed Persian rose petals, and sparkling mountain spring water.',
      descriptionFa: 'دوغ خنک و گازدار محلی با عطر پونه، نعناع خشک و گلبرگ‌های گل سرخ.',
      price: 2.90,
      image: 'https://images.unsplash.com/photo-1541658016709-82535e94bc69?auto=format&fit=crop&w=400&h=250&q=80',
      isAvailable: true,
      prepTimeMinutes: 5,
      calories: 90,
      isVegetarian: true,
      isSpicy: false,
      ratingsCount: 110,
      averageRating: 4.9
    },
    {
      id: 'item_bu_201',
      restaurantId: 'rest_burger',
      categoryId: 'cat_bu_1',
      name: 'Double Truffle Smash',
      nameFa: 'دبل ترافل اسمش',
      description: 'Two smashed grass-fed beef patties, double cheddar, caramelized onions, wild mushroom confit, and black truffle aioli.',
      descriptionFa: 'دو عدد پتی اسمش‌شده گوسفندی، پنیر چدار دوبل، پیاز کاراملی، قارچ وحشی پخته و سس ترافل مشکی.',
      price: 12.90,
      discountPrice: 10.90,
      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=400&h=250&q=80',
      isAvailable: true,
      prepTimeMinutes: 12,
      calories: 950,
      isVegetarian: false,
      isSpicy: false,
      ratingsCount: 312,
      averageRating: 4.9
    },
    {
      id: 'item_bu_202',
      restaurantId: 'rest_burger',
      categoryId: 'cat_bu_1',
      name: 'Spicy Volcano Burger',
      nameFa: 'ولکانو برگر تند',
      description: 'Crispy hand-breaded chicken breast, jalapeño slaw, molten pepper-jack cheese, and fiery Nashville hot sauce.',
      descriptionFa: 'سینه مرغ ترد سوخاری شده، سالاد کلم با هالوپینو، پنیر جک فلفلی مذاب و سس تند نشویل.',
      price: 11.50,
      image: 'https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format&fit=crop&w=400&h=250&q=80',
      isAvailable: true,
      prepTimeMinutes: 10,
      calories: 820,
      isVegetarian: false,
      isSpicy: true,
      ratingsCount: 145,
      averageRating: 4.6
    },
    {
      id: 'item_bu_203',
      restaurantId: 'rest_burger',
      categoryId: 'cat_bu_2',
      name: 'Cheesy Garlic Fries',
      nameFa: 'سیب‌زمینی سیر و پنیر',
      description: 'Thick-cut golden fries, tossed in white truffle oil, roasted minced garlic, parsley, and snowed-over parmesan cheese.',
      descriptionFa: 'سیب‌زمینی سرخ‌شده ترد با روغن ترافل سفید، سیر رنده شده رست‌شده، جعفری و پنیر پارمسان رنده‌شده فراوان.',
      price: 6.20,
      image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=400&h=250&q=80',
      isAvailable: true,
      prepTimeMinutes: 8,
      calories: 540,
      isVegetarian: true,
      isSpicy: false,
      ratingsCount: 94,
      averageRating: 4.8
    }
  ],
  tables: [
    { id: 'tab_sh_1', restaurantId: 'rest_shandiz', tableNumber: '1', status: 'empty', qrUrl: '/r/shandiz?table=1' },
    { id: 'tab_sh_2', restaurantId: 'rest_shandiz', tableNumber: '2', status: 'occupied', qrUrl: '/r/shandiz?table=2' },
    { id: 'tab_sh_3', restaurantId: 'rest_shandiz', tableNumber: '3', status: 'empty', qrUrl: '/r/shandiz?table=3' },
    { id: 'tab_sh_4', restaurantId: 'rest_shandiz', tableNumber: '4', status: 'needs_cleaning', qrUrl: '/r/shandiz?table=4' },
    { id: 'tab_bu_1', restaurantId: 'rest_burger', tableNumber: 'T1', status: 'empty', qrUrl: '/r/burgerlab?table=T1' },
    { id: 'tab_bu_2', restaurantId: 'rest_burger', tableNumber: 'T2', status: 'occupied', qrUrl: '/r/burgerlab?table=T2' },
    { id: 'tab_bu_3', restaurantId: 'rest_burger', tableNumber: 'T3', status: 'empty', qrUrl: '/r/burgerlab?table=T3' }
  ],
  orders: [
    {
      id: 'ord_1',
      restaurantId: 'rest_burger',
      tableId: 'tab_bu_2',
      tableNumber: 'T2',
      customerName: 'Sina',
      customerPhone: '09123456789',
      items: [
        { menuItemId: 'item_bu_201', name: 'Double Truffle Smash', nameFa: 'دبل ترافل اسمش', price: 10.90, quantity: 2, notes: 'Medium rare please' },
        { menuItemId: 'item_bu_203', name: 'Cheesy Garlic Fries', nameFa: 'سیب‌زمینی سیر و پنیر', price: 6.20, quantity: 1 }
      ],
      type: 'dine_in',
      status: 'preparing',
      subtotal: 28.00,
      discount: 0,
      total: 28.00,
      pointsEarned: 420,
      createdAt: '2026-07-15T20:00:00Z',
      updatedAt: '2026-07-15T20:05:00Z'
    },
    {
      id: 'ord_2',
      restaurantId: 'rest_shandiz',
      tableId: 'tab_sh_2',
      tableNumber: '2',
      customerName: 'Ali',
      items: [
        { menuItemId: 'item_sh_101', name: 'Shandiz Royal Kebab (Shashlik)', nameFa: 'شیشلیک مخصوص شاندیز', price: 24.50, quantity: 1 },
        { menuItemId: 'item_sh_104', name: 'Traditional Saffron Doogh', nameFa: 'دوغ محلی با نعناع و گل سرخ', price: 2.90, quantity: 2 }
      ],
      type: 'dine_in',
      status: 'ready',
      subtotal: 30.30,
      discount: 3.03,
      total: 27.27,
      pointsEarned: 272,
      couponApplied: 'OFF10',
      createdAt: '2026-07-15T19:30:00Z',
      updatedAt: '2026-07-15T19:50:00Z'
    },
    {
      id: 'ord_3',
      restaurantId: 'rest_burger',
      customerName: 'Sara',
      customerPhone: '09171112222',
      deliveryAddress: 'Moallem Blvd, House #14, Shiraz',
      items: [
        { menuItemId: 'item_bu_202', name: 'Spicy Volcano Burger', nameFa: 'ولکانو برگر تند', price: 11.50, quantity: 1 }
      ],
      type: 'delivery',
      status: 'completed',
      subtotal: 11.50,
      discount: 0,
      total: 11.50,
      pointsEarned: 172,
      createdAt: '2026-07-15T18:00:00Z',
      updatedAt: '2026-07-15T18:40:00Z'
    }
  ],
  reviews: [
    {
      id: 'rev_1',
      restaurantId: 'rest_shandiz',
      menuItemId: 'item_sh_101',
      customerName: 'Ahmad Reza',
      rating: 5,
      comment: 'Absolutely the best Shashlik in Tehran! Saffron aroma is magnificent.',
      createdAt: '2026-07-10T14:30:00Z'
    },
    {
      id: 'rev_2',
      restaurantId: 'rest_burger',
      menuItemId: 'item_bu_201',
      customerName: 'Yasaman',
      rating: 5,
      comment: 'The truffle sauce is mouthwatering. Highly recommend!',
      createdAt: '2026-07-12T19:15:00Z'
    }
  ],
  coupons: [
    { id: 'cp_1', restaurantId: 'rest_shandiz', code: 'OFF10', discountPercent: 10, minOrderValue: 20, expiresAt: '2026-12-31', isActive: true },
    { id: 'cp_2', restaurantId: 'rest_burger', code: 'WELCOME', discountPercent: 15, minOrderValue: 10, expiresAt: '2026-12-31', isActive: true }
  ]
};

// Initial setup to write DB file if it does not exist
export function initDB() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultDatabase, null, 2), 'utf-8');
  }
}

// Low-level helper to read database
export function readDB(): DatabaseSchema {
  initDB();
  try {
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading db.json, returning default database schema', err);
    return defaultDatabase;
  }
}

// Low-level helper to write database
export function writeDB(db: DatabaseSchema) {
  initDB();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
}
